import 'react-native-gesture-handler'; // must be first import for drawer nav
import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { DatabaseProvider } from '@nozbe/watermelondb/DatabaseProvider';
import { database } from './src/models/database';
import { initSyncListener } from './src/services/syncService';
import { setupNotifications } from './src/services/notificationService';
import RootNavigator from './src/navigation/RootNavigator';
import { colors } from './src/constants/colors';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry:          2,
      staleTime:      1000 * 60 * 5,  // 5 min
      gcTime:         1000 * 60 * 30, // 30 min
    },
  },
});

export default function App() {
  useEffect(() => {
    initSyncListener();
    setupNotifications().catch(console.warn);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <DatabaseProvider database={database}>
        <StatusBar barStyle="light-content" backgroundColor={colors.brown} />
        <RootNavigator />
      </DatabaseProvider>
    </QueryClientProvider>
  );
}
