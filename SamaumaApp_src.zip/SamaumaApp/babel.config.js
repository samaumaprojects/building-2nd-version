module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: [
    // WatermelonDB requires decorators
    ['@babel/plugin-proposal-decorators', { legacy: true }],
  ],
};
