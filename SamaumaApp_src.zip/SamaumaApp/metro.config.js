const { getDefaultConfig, mergeConfig } = require('@react-native/metro-config');

/**
 * Metro configuration
 * https://reactnative.dev/docs/metro
 */

/** @type {import('metro-config').MetroConfig} */
const config = {
  transformer: {
    // WatermelonDB SQLite JSI needs this
    getTransformOptions: async () => ({
      transform: {
        experimentalImportSupport: false,
        inlineRequires: true,
      },
    }),
  },
  resolver: {
    // Support for .cjs modules (Zod, etc.)
    sourceExts: ['js', 'jsx', 'ts', 'tsx', 'cjs', 'json'],
  },
};

module.exports = mergeConfig(getDefaultConfig(__dirname), config);
