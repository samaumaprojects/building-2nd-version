#!/bin/bash
# ============================================================
# Samaúma App — Script de setup iOS
# Execute este script uma vez para configurar o projeto nativo
# Usage: bash setup_ios.sh
# ============================================================

set -e
APP_DIR="/Users/biancacardozoflores/SamaumaApp"
cd "$APP_DIR"

echo ""
echo "=== 1. Instalando dependências npm ==="
npm install

echo ""
echo "=== 2. Configurando autenticação Mapbox (necessário para pod install) ==="
NETRC="$HOME/.netrc"

if grep -q "api.mapbox.com" "$NETRC" 2>/dev/null; then
  echo "→ ~/.netrc já tem credenciais Mapbox, pulando"
else
  echo ""
  echo "  O @rnmapbox/maps v10 requer um token SECRETO do Mapbox (começa com 'sk.')"
  echo "  Obtenha em: https://account.mapbox.com → Tokens → Create a secret token"
  echo "  O token precisa ter o escopo: DOWNLOADS:READ"
  echo ""
  read -r -p "  Cole seu Mapbox SECRET token (sk.eyJ...): " MAPBOX_SECRET

  if [[ "$MAPBOX_SECRET" == sk.* ]]; then
    cat >> "$NETRC" << EOF

machine api.mapbox.com
  login mapbox
  password $MAPBOX_SECRET
EOF
    chmod 600 "$NETRC"
    echo "→ ~/.netrc configurado com sucesso"
  else
    echo "⚠️  Token inválido (deve começar com 'sk.'). Configuração pulada."
    echo "   Execute: echo -e 'machine api.mapbox.com\\n  login mapbox\\n  password SEU_SK_TOKEN' >> ~/.netrc"
  fi
fi

echo ""
echo "=== 3. Gerando projeto iOS nativo ==="
if [ ! -d "ios" ]; then
  # Cria projeto temporário para extrair ios/
  TEMP_DIR="/tmp/SamaumaTemp_$$"
  npx react-native@0.74.5 init SamaumaApp --directory "$TEMP_DIR" --skip-git-init --npm
  cp -r "$TEMP_DIR/ios" "$APP_DIR/ios"
  rm -rf "$TEMP_DIR"
  echo "→ pasta ios/ criada"
else
  echo "→ pasta ios/ já existe, pulando"
fi

echo ""
echo "=== 4. Instalando CocoaPods ==="
cd "$APP_DIR/ios"

# Verifica se CocoaPods está instalado
if ! command -v pod &> /dev/null; then
  echo "CocoaPods não encontrado. Instalando..."
  sudo gem install cocoapods
fi

pod install --repo-update
cd "$APP_DIR"

echo ""
echo "============================================================"
echo "✅ Setup concluído!"
echo ""
echo "Próximos passos:"
echo ""
echo "  1. Abra src/config.ts e substitua 'pk.SEU_TOKEN_MAPBOX_AQUI'"
echo "     pelo seu token PÚBLICO do Mapbox (começa com 'pk.')"
echo "     Obtenha em: https://account.mapbox.com → Tokens"
echo ""
echo "  2. Certifique-se que a API Laravel está rodando:"
echo "     cd /Users/biancacardozoflores/Downloads/Api_Samauna-main/api"
echo "     php artisan serve"
echo ""
echo "  3. Execute o app no simulador iOS:"
echo "     npx react-native run-ios"
echo "     ou abra ios/SamaumaApp.xcworkspace no Xcode"
echo "============================================================"
