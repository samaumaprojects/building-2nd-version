import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { colors } from '../constants/colors';

interface Props {
  label:    string;
  sublabel?: string;
  value:    number;
  onChange: (v: number) => void;
  step?:    number;
  min?:     number;
}

export default function CounterField({ label, sublabel, value, onChange, step = 1, min = 0 }: Props) {
  return (
    <View style={s.row}>
      <View style={s.labelWrap}>
        <Text style={s.label}>{label}</Text>
        {sublabel ? <Text style={s.sublabel}>{sublabel}</Text> : null}
      </View>
      <View style={s.controls}>
        <TouchableOpacity
          style={s.btn}
          onPress={() => onChange(Math.max(min, value - step))}
          hitSlop={{ top: 14, bottom: 14, left: 14, right: 14 }}
          activeOpacity={0.7}
        >
          <Text style={s.btnText}>−</Text>
        </TouchableOpacity>
        <Text style={s.value}>{value.toLocaleString('pt-BR')}</Text>
        <TouchableOpacity
          style={s.btn}
          onPress={() => onChange(value + step)}
          hitSlop={{ top: 14, bottom: 14, left: 14, right: 14 }}
          activeOpacity={0.7}
        >
          <Text style={s.btnText}>+</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  row:       { backgroundColor: colors.white, borderRadius: 10, padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6, shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  labelWrap: { flex: 1, marginRight: 10 },
  label:     { fontSize: 13, fontWeight: '700', color: colors.brown },
  sublabel:  { fontSize: 11, color: '#888', fontStyle: 'italic', marginTop: 1 },
  controls:  { flexDirection: 'row', alignItems: 'center', gap: 8 },
  btn:       { width: 30, height: 30, borderRadius: 8, backgroundColor: colors.sage, justifyContent: 'center', alignItems: 'center' },
  btnText:   { fontSize: 18, fontWeight: '700', color: colors.green, lineHeight: 20 },
  value:     { fontSize: 15, fontWeight: '700', color: colors.brown, minWidth: 44, textAlign: 'center' },
});
