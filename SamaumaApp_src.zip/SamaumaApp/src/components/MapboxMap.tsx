import React from 'react';
import Mapbox from '@rnmapbox/maps';
import { MAPBOX_TOKEN } from '../config';
import { mapStyles } from '../constants/colors';

// Inicializa o SDK Mapbox — chamado uma vez no import
Mapbox.setAccessToken(MAPBOX_TOKEN);

interface Props {
  center:    [number, number]; // [longitude, latitude]
  zoom?:     number;
  children?: React.ReactNode;
  style?:    object;
  onPress?:  (e: any) => void;
}

export default function MapboxMap({ center, zoom = 14, children, style, onPress }: Props) {
  return (
    <Mapbox.MapView
      styleURL={mapStyles.satellite}
      style={[{ flex: 1 }, style]}
      compassEnabled
      scaleBarEnabled={false}
      onPress={onPress}
    >
      <Mapbox.Camera
        centerCoordinate={center}
        zoomLevel={zoom}
        animationMode="flyTo"
        animationDuration={600}
      />
      {children}
    </Mapbox.MapView>
  );
}

/** Calcula o centro geográfico de um polígono GeoJSON */
export function getBboxCenter(polygon: any): [number, number] {
  if (!polygon?.coordinates?.[0]) return [-44.42, -2.40];
  const coords = polygon.coordinates[0];
  const lngs = coords.map((c: number[]) => c[0]);
  const lats = coords.map((c: number[]) => c[1]);
  return [
    (Math.min(...lngs) + Math.max(...lngs)) / 2,
    (Math.min(...lats) + Math.max(...lats)) / 2,
  ];
}
