import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import NetInfo from '@react-native-community/netinfo';

export default function OfflineBanner() {
  const [offline, setOffline] = useState(false);

  useEffect(() => {
    const unsub = NetInfo.addEventListener(state => {
      setOffline(!state.isConnected);
    });
    return () => unsub();
  }, []);

  if (!offline) return null;
  return (
    <View style={s.banner}>
      <Text style={s.text}>⚠ Offline — dados salvos localmente</Text>
    </View>
  );
}

const s = StyleSheet.create({
  banner: { backgroundColor: 'rgba(196,135,93,0.92)', paddingVertical: 6, alignItems: 'center' },
  text:   { color: '#fff', fontWeight: '700', fontSize: 12 },
});
