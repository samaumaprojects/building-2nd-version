import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const STATUS_CONFIG: Record<string, { bg: string; text: string; label: string }> = {
  // Status da API real (projetos)
  ativo:      { bg: '#d4edda', text: '#2d7a40', label: 'Ativo'        },
  concluido:  { bg: '#e0e7ff', text: '#3730a3', label: 'Concluído'    },
  planejado:  { bg: '#fef3c7', text: '#92660a', label: 'Planejado'    },
  cancelado:  { bg: '#fee2e2', text: '#991b1b', label: 'Cancelado'    },
  // Legados / compatibilidade
  pending:    { bg: '#fde8d8', text: '#8b3a1a', label: 'Pendente'     },
  in_progress:{ bg: '#fef3c7', text: '#92660a', label: 'Em andamento' },
  completed:  { bg: '#d4edda', text: '#2d7a40', label: 'Concluída'    },
  overdue:    { bg: '#fee2e2', text: '#991b1b', label: 'Atrasada'     },
  draft:      { bg: '#fef3c7', text: '#92660a', label: 'Rascunho'     },
};

export default function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] ?? { bg: '#e5e7eb', text: '#374151', label: status };
  return (
    <View style={[s.badge, { backgroundColor: cfg.bg }]}>
      <Text style={[s.text, { color: cfg.text }]}>{cfg.label}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  badge: { borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3, alignSelf: 'flex-start' },
  text:  { fontSize: 10, fontWeight: '700', letterSpacing: 0.3 },
});
