/**
 * Configuração da aplicação Samaúma
 *
 * ⚠️  Coloque seu token real do Mapbox abaixo.
 *     Obtenha em: https://account.mapbox.com/
 *
 * ⚠️  Nunca commite tokens reais em repositórios públicos.
 *     Adicione este arquivo ao .gitignore se necessário.
 */

export const MAPBOX_TOKEN = 'pk.eyJ1Ijoic2FtYXVtYSIsImEiOiJjbWVjenFwZ3EwNHFsMnhvaXAzZ3EwdnVjIn0.SmNbLIdN8Qq2IagweDf_3Q';

/**
 * URL base da API Laravel.
 * - iOS Simulator: 'http://localhost:8000/api'
 * - Android Emulator: 'http://10.0.2.2:8000/api'
 * - Dispositivo físico / rede local: 'http://SEU_IP_LOCAL:8000/api'
 * - Produção: 'https://api.samaumaacoes.org/api'
 */
export const API_URL = __DEV__
  ? 'http://localhost:8000/api'
  : 'https://api.samaumaacoes.org/api';
