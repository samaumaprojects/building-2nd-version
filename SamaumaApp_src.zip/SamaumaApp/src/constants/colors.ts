export const colors = {
  brown:       '#342219',
  green:       '#494E3A',
  terracotta:  '#C4875D',
  sage:        '#D1D1A7',
  cream:       '#FFF7E8',
  white:       '#FFFFFF',
  pinDone:     '#2d7a40',
  pinDraft:    '#92660a',
  pinPending:  '#C4875D',
  errorRed:    '#f87171',
  successGreen:'#4ade80',
};

export const mapStyles = {
  satellite: 'mapbox://styles/mapbox/satellite-streets-v12',
};
