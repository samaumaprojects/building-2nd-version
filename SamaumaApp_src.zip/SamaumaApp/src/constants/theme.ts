import { StyleSheet } from 'react-native';
import { colors } from './colors';

export const theme = StyleSheet.create({
  screen:        { flex: 1, backgroundColor: colors.cream },
  scrollContent: { paddingHorizontal: 16, paddingBottom: 40, paddingTop: 12 },
  card: {
    backgroundColor: colors.white,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    shadowColor: colors.brown,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  sectionLabel: {
    fontSize: 9, fontWeight: '700', letterSpacing: 1.2,
    textTransform: 'uppercase', color: colors.terracotta,
    marginTop: 16, marginBottom: 8,
  },
  fieldLabel: {
    fontSize: 11, fontWeight: '700', letterSpacing: 0.6,
    textTransform: 'uppercase', color: colors.green, marginBottom: 5,
  },
  input: {
    backgroundColor: colors.white, borderWidth: 1.5,
    borderColor: 'rgba(209,209,167,0.7)', borderRadius: 9,
    paddingHorizontal: 12, paddingVertical: 10,
    fontSize: 14, color: colors.brown, marginBottom: 4,
  },
  inputError:  { borderColor: colors.errorRed },
  fieldError:  { color: colors.errorRed, fontSize: 11, marginBottom: 8 },
  primaryBtn: {
    backgroundColor: colors.terracotta, borderRadius: 10,
    paddingVertical: 13, alignItems: 'center', marginTop: 8,
  },
  primaryBtnText: { color: colors.white, fontWeight: '700', fontSize: 13, letterSpacing: 1 },
  secondaryBtn: {
    backgroundColor: 'transparent', borderRadius: 10, borderWidth: 1.5,
    borderColor: 'rgba(73,78,58,0.4)', paddingVertical: 11,
    alignItems: 'center', marginTop: 6,
  },
  secondaryBtnText: { color: colors.brown, fontWeight: '700', fontSize: 13 },
  headerTitle: { fontWeight: '700', fontSize: 18, color: colors.cream },
  statusBadge: {
    borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2, alignSelf: 'flex-start',
  },
});
