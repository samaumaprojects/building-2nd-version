import React from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuthStore } from './authStore';
import { colors } from '../../constants/colors';

const loginSchema = z.object({
  email:    z.string().email('Email inválido'),
  password: z.string().min(6, 'Mínimo 6 caracteres'),
});
type LoginForm = z.infer<typeof loginSchema>;

export default function LoginScreen() {
  const { login, isLoading, error } = useAuthStore();
  const { control, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  return (
    <KeyboardAvoidingView
      style={s.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={s.inner}>
        <Text style={s.logo}>Samaúma</Text>
        <Text style={s.sub}>Field App</Text>

        {error ? <Text style={s.errorBanner}>{error}</Text> : null}

        <Controller
          name="email" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <>
              <TextInput
                style={[s.input, errors.email && s.inputError]}
                placeholder="Email" placeholderTextColor="#888"
                autoCapitalize="none" keyboardType="email-address"
                value={value} onChangeText={onChange} onBlur={onBlur}
              />
              {errors.email && <Text style={s.fieldError}>{errors.email.message}</Text>}
            </>
          )}
        />

        <Controller
          name="password" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <>
              <TextInput
                style={[s.input, errors.password && s.inputError]}
                placeholder="Senha" placeholderTextColor="#888"
                secureTextEntry value={value}
                onChangeText={onChange} onBlur={onBlur}
              />
              {errors.password && <Text style={s.fieldError}>{errors.password.message}</Text>}
            </>
          )}
        />

        <TouchableOpacity
          style={[s.btn, isLoading && s.btnDisabled]}
          onPress={handleSubmit((d) => login(d.email, d.password))}
          disabled={isLoading}
        >
          {isLoading
            ? <ActivityIndicator color="#fff" />
            : <Text style={s.btnText}>Entrar</Text>
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  container:  { flex: 1, backgroundColor: colors.brown },
  inner:      { flex: 1, justifyContent: 'center', paddingHorizontal: 32 },
  logo:       { fontSize: 34, color: colors.cream, textAlign: 'center', marginBottom: 4, fontWeight: '700' },
  sub:        { fontSize: 11, color: colors.terracotta, textAlign: 'center', letterSpacing: 4, textTransform: 'uppercase', marginBottom: 48 },
  errorBanner:{ backgroundColor: 'rgba(200,60,60,0.15)', borderRadius: 8, padding: 10, color: '#f87171', fontSize: 13, marginBottom: 14, textAlign: 'center' },
  input:      { backgroundColor: 'rgba(255,255,255,0.09)', borderRadius: 10, padding: 14, color: colors.cream, fontSize: 15, marginBottom: 4, borderWidth: 1, borderColor: 'rgba(209,209,167,0.2)' },
  inputError: { borderColor: '#f87171' },
  fieldError: { color: '#f87171', fontSize: 11, marginBottom: 10, marginLeft: 2 },
  btn:        { backgroundColor: colors.terracotta, borderRadius: 10, padding: 15, alignItems: 'center', marginTop: 16 },
  btnDisabled:{ opacity: 0.6 },
  btnText:    { color: '#fff', fontWeight: '700', fontSize: 15, letterSpacing: 1 },
});
