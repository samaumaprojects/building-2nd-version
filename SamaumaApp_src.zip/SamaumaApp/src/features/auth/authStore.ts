import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import api from '../../services/api';

export interface AuthUser {
  id:                  string;
  name:                string;
  email:               string;
  role:                'admin' | 'field_leader';
  assigned_project_id?: string;
}

interface AuthState {
  user:      AuthUser | null;
  token:     string | null;
  isLoading: boolean;
  error:     string | null;
  login:      (email: string, password: string) => Promise<void>;
  logout:     () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user:      null,
      token:     null,
      isLoading: false,
      error:     null,

      login: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const { data } = await api.post('/login', { email, password });
          const user: AuthUser = {
            id:                  String(data.user.id),
            name:                data.user.name,
            email:               data.user.email,
            role:                data.user.role ?? 'field_leader',
            assigned_project_id: data.user.assigned_project_id ?? undefined,
          };
          set({ user, token: data.access_token, isLoading: false });
        } catch (e: any) {
          const msg = e?.response?.data?.message ?? 'Erro ao fazer login';
          set({ error: msg, isLoading: false });
        }
      },

      logout: () => {
        api.post('/logout').catch(() => {});
        set({ user: null, token: null });
      },

      clearError: () => set({ error: null }),
    }),
    {
      name:    'samauma-auth',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user:  state.user,
        token: state.token,
      }),
    }
  )
);
