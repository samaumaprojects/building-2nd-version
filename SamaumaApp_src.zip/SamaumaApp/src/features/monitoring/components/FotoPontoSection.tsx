import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, Image,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { captureGeoPhoto, getMediaForOwner, deleteMediaItem } from '../../../services/geoMediaService';
import { colors } from '../../../constants/colors';
import type MediaItem from '../../../models/MediaItem';

const BORDA_COUNT = 10;

interface Props {
  formId:    string;
  onChange?: (isComplete: boolean) => void;
}

export default function FotoPontoSection({ formId, onChange }: Props) {
  const [fotoponto, setFotoponto] = useState<MediaItem | null>(null);
  const [bordas, setBordas]       = useState<MediaItem[]>([]);
  const [loading, setLoading]     = useState<number | 'fotoponto' | null>(null);

  useEffect(() => { loadMedia(); }, [formId]);

  const loadMedia = async () => {
    const all = await getMediaForOwner(formId, 'monitoring_form');
    const fp  = all.find(m => m.role === 'fotoponto') ?? null;
    const bd  = all.filter(m => m.role === 'borda');
    setFotoponto(fp);
    setBordas(bd);
    onChange?.(!!fp && bd.length === BORDA_COUNT);
  };

  const takeFotoponto = async () => {
    setLoading('fotoponto');
    await captureGeoPhoto(formId, 'monitoring_form', 'fotoponto');
    setLoading(null);
    loadMedia();
  };

  const takeBorda = async (index: number) => {
    if (bordas.length >= BORDA_COUNT) return;
    setLoading(index);
    await captureGeoPhoto(formId, 'monitoring_form', 'borda');
    setLoading(null);
    loadMedia();
  };

  const confirmDelete = (localId: string, label: string) => {
    Alert.alert('Remover foto', `Remover ${label}?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Remover', style: 'destructive', onPress: async () => {
        await deleteMediaItem(localId);
        loadMedia();
      }},
    ]);
  };

  const isComplete = !!fotoponto && bordas.length === BORDA_COUNT;
  const progress   = (fotoponto ? 1 : 0) + bordas.length;

  return (
    <View>
      <View style={s.progressHeader}>
        <Text style={s.progressLabel}>
          Fotos de campo · {progress}/11{isComplete ? ' ✓' : ''}
        </Text>
        <View style={s.progressBar}>
          <View style={[s.progressFill, { width: `${(progress / 11) * 100}%` as any }]} />
        </View>
      </View>

      <Text style={s.slotTitle}>Fotoponto — Centro da Amostra</Text>
      <TouchableOpacity
        style={[s.fotopontoSlot, fotoponto && s.slotFilled]}
        onPress={fotoponto ? () => confirmDelete(fotoponto.id, 'fotoponto') : takeFotoponto}
        activeOpacity={0.8}
      >
        {loading === 'fotoponto' ? (
          <ActivityIndicator color={colors.terracotta} size="large" />
        ) : fotoponto ? (
          <>
            <Image source={{ uri: fotoponto.localUri }} style={s.fotopontoImage} />
            <View style={s.gpsOverlay}>
              <Text style={s.gpsText}>
                {(fotoponto.latitude ?? 0).toFixed(5)}, {(fotoponto.longitude ?? 0).toFixed(5)}
              </Text>
            </View>
          </>
        ) : (
          <View style={s.emptySlotContent}>
            <Text style={s.emptySlotIcon}>📷</Text>
            <Text style={s.emptySlotText}>Fotografar centro</Text>
          </View>
        )}
      </TouchableOpacity>

      <Text style={s.slotTitle}>Fotos de Borda — {bordas.length}/{BORDA_COUNT}</Text>
      <View style={s.bordaGrid}>
        {Array.from({ length: BORDA_COUNT }).map((_, idx) => {
          const photo     = bordas[idx] ?? null;
          const isLoading = loading === idx;
          return (
            <TouchableOpacity
              key={idx}
              style={[s.bordaSlot, photo && s.slotFilled]}
              onPress={photo ? () => confirmDelete(photo.id, `borda ${idx + 1}`) : () => takeBorda(idx)}
              disabled={!photo && bordas.length >= BORDA_COUNT}
              activeOpacity={0.8}
            >
              {isLoading ? (
                <ActivityIndicator color={colors.terracotta} size="small" />
              ) : photo ? (
                <Image source={{ uri: photo.localUri }} style={s.bordaImage} />
              ) : (
                <Text style={s.bordaEmptyNum}>B{idx + 1}</Text>
              )}
            </TouchableOpacity>
          );
        })}
      </View>

      {!isComplete && (
        <Text style={s.incomplete}>
          1 fotoponto + 10 fotos de borda para concluir.
        </Text>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  progressHeader:  { marginBottom: 12 },
  progressLabel:   { fontSize: 12, fontWeight: '700', color: colors.brown, marginBottom: 5 },
  progressBar:     { height: 5, backgroundColor: colors.sage, borderRadius: 3, overflow: 'hidden' },
  progressFill:    { height: 5, backgroundColor: colors.terracotta, borderRadius: 3 },
  slotTitle:       { fontSize: 11, fontWeight: '700', color: colors.green, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 16, marginBottom: 4 },
  fotopontoSlot:   { height: 160, borderRadius: 12, borderWidth: 1.5, borderStyle: 'dashed', borderColor: 'rgba(196,135,93,0.5)', backgroundColor: 'rgba(196,135,93,0.05)', justifyContent: 'center', alignItems: 'center', overflow: 'hidden', marginBottom: 4 },
  slotFilled:      { borderStyle: 'solid', borderColor: colors.terracotta },
  fotopontoImage:  { width: '100%', height: '100%', resizeMode: 'cover' },
  gpsOverlay:      { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(52,34,25,0.78)', padding: 5 },
  gpsText:         { color: '#FFF7E8', fontSize: 9, fontFamily: 'Courier' },
  emptySlotContent:{ alignItems: 'center', gap: 4 },
  emptySlotIcon:   { fontSize: 28 },
  emptySlotText:   { fontSize: 12, fontWeight: '700', color: colors.terracotta },
  bordaGrid:       { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  bordaSlot:       { width: '18.5%' as any, aspectRatio: 1, borderRadius: 8, borderWidth: 1.5, borderStyle: 'dashed', borderColor: 'rgba(196,135,93,0.4)', backgroundColor: 'rgba(196,135,93,0.05)', justifyContent: 'center', alignItems: 'center', overflow: 'hidden' },
  bordaImage:      { width: '100%', height: '100%', resizeMode: 'cover' },
  bordaEmptyNum:   { fontSize: 9, color: '#aaa', fontWeight: '700' },
  incomplete:      { fontSize: 11, color: '#8b3a1a', backgroundColor: '#fde8d8', borderRadius: 7, padding: 9, marginTop: 4 },
});
