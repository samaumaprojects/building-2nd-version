import React from 'react';
import Mapbox from '@rnmapbox/maps';
import { colors } from '../../../constants/colors';

interface Point { id: string; latitude: number; longitude: number; label: string; }
interface Form  { sample_point_id: string; form_status: string; }

export default function SamplePinLayer({
  points, forms, onPinPress,
}: { points: Point[]; forms: Form[]; onPinPress: (id: string) => void }) {

  const pinColor = (pointId: string) => {
    const form = forms.find(f => f.sample_point_id === pointId);
    if (!form)                           return colors.pinPending;
    if (form.form_status === 'completed') return colors.pinDone;
    if (form.form_status === 'draft')     return colors.pinDraft;
    return colors.pinPending;
  };

  const geoJSON = {
    type: 'FeatureCollection',
    features: points.map(p => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [p.longitude, p.latitude] },
      properties: { id: p.id, label: p.label, color: pinColor(p.id) },
    })),
  };

  return (
    <Mapbox.ShapeSource
      id="samplePins"
      shape={geoJSON as any}
      onPress={(e) => {
        const id = e.features[0]?.properties?.id;
        if (id) onPinPress(id);
      }}
    >
      <Mapbox.CircleLayer id="pinsCircle"
        style={{
          circleColor:       ['get', 'color'] as any,
          circleRadius:      11,
          circleStrokeWidth: 2.5,
          circleStrokeColor: '#fff',
        }}
      />
      <Mapbox.SymbolLayer id="pinsLabel"
        style={{ textField: ['get', 'label'] as any, textSize: 10, textColor: '#fff', textFont: ['DIN Pro Bold'], textAnchor: 'center' }}
      />
    </Mapbox.ShapeSource>
  );
}
