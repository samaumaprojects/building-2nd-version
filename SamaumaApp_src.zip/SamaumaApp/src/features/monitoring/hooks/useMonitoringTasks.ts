import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { Q } from '@nozbe/watermelondb';
import api from '../../../services/api';
import { database, collections } from '../../../models/database';
import type { ApiMonitoringTask, ApiMonitoringForm } from '../../../services/api';

export function useTasksForSession(sessionId: string) {
  const query = useQuery({
    queryKey: ['tasks', sessionId],
    queryFn: async () => {
      const { data } = await api.get<ApiMonitoringTask[]>(`/sessions/${sessionId}/monitoring-tasks`);
      return data;
    },
    enabled: !!sessionId,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (query.data) syncTasksToLocal(query.data, sessionId);
  }, [query.data]);

  return query;
}

export function useTask(taskId: string) {
  return useQuery({
    queryKey: ['task', taskId],
    queryFn: async () => {
      const { data } = await api.get<ApiMonitoringTask>(`/monitoring-tasks/${taskId}`);
      return data;
    },
    enabled: !!taskId,
  });
}

export function useUpdateTaskStatus(taskId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (status: string) =>
      api.patch(`/monitoring-tasks/${taskId}/status`, { status }).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['task', taskId] });
    },
  });
}

export function useCreateMonitoringForm() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      task_id:                   string;
      sample_point_id:           string;
      observer_name:             string;
      observed_at:               number;
      species:                   string;
      alive_count:               number;
      dead_count:                number;
      dormant_count:             number;
      natural_recovery_count?:   number;
      natural_recovery_species?: string;
      salinity?:                 number;
      crab_burrows?:             number;
      height_cm?:                number;
      stem_diameter_mm?:         number;
      leaf_count?:               number;
      notes?:                    string;
      form_status:               'draft' | 'completed';
    }) => {
      // Offline-first: save locally
      let localId: string | null = null;
      await database.write(async () => {
        const record = await collections.forms().create(r => {
          r.taskId                  = payload.task_id;
          r.samplePointId           = payload.sample_point_id;
          r.observerName            = payload.observer_name;
          r.observedAt              = payload.observed_at;
          r.species                 = payload.species;
          r.aliveCount              = payload.alive_count;
          r.deadCount               = payload.dead_count;
          r.dormantCount            = payload.dormant_count;
          r.naturalRecoveryCount    = payload.natural_recovery_count ?? null;
          r.naturalRecoverySpecies  = payload.natural_recovery_species ?? null;
          r.salinity                = payload.salinity ?? null;
          r.crabBurrows             = payload.crab_burrows ?? null;
          r.heightCm                = payload.height_cm ?? null;
          r.stemDiameterMm          = payload.stem_diameter_mm ?? null;
          r.leafCount               = payload.leaf_count ?? null;
          r.notes                   = payload.notes ?? null;
          r.formStatus              = payload.form_status;
          r.synced                  = false;
        });
        localId = record.id;
      });

      try {
        const { data } = await api.post<ApiMonitoringForm>('/monitoring-forms', payload);
        if (localId) {
          const local = await collections.forms().find(localId);
          await database.write(async () => {
            await local.update(r => {
              r.remoteId = String(data.id);
              r.synced   = true;
            });
          });
        }
        return { data, localId };
      } catch {
        return { data: null, localId };
      }
    },
    onSuccess: (_result, payload) => {
      qc.invalidateQueries({ queryKey: ['task', payload.task_id] });
    },
  });
}

export function useUpdateMonitoringForm(formId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: Partial<ApiMonitoringForm>) =>
      api.put(`/monitoring-forms/${formId}`, payload).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['task'] });
    },
  });
}

export function useDeleteMonitoringForm(formId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.delete(`/monitoring-forms/${formId}`).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['task'] });
    },
  });
}

async function syncTasksToLocal(tasks: ApiMonitoringTask[], sessionId: string) {
  await database.write(async () => {
    for (const t of tasks) {
      const existing = await collections.tasks()
        .query(Q.where('remote_id', String(t.id))).fetch();
      if (existing.length > 0) {
        await existing[0].update(r => {
          r.stage   = t.stage;
          r.dueDate = t.due_date;
          r.status  = t.status;
          r.synced  = true;
        });
      } else {
        await collections.tasks().create(r => {
          r.remoteId  = String(t.id);
          r.sessionId = sessionId;
          r.stage     = t.stage;
          r.dueDate   = t.due_date;
          r.status    = t.status;
          r.synced    = true;
        });
      }
    }
  });
}
