import React, { useState } from 'react';
import {
  View, Text, ScrollView, TextInput, TouchableOpacity,
  StyleSheet, Alert, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import RNPickerSelect from 'react-native-picker-select';
import OfflineBanner from '../../../components/OfflineBanner';
import FotoPontoSection from '../components/FotoPontoSection';
import { useCreateMonitoringForm } from '../hooks/useMonitoringTasks';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import CounterField from '../../../components/CounterField';

interface Props { route: any; navigation: any; }

const formSchema = z.object({
  observer_name:             z.string().min(1, 'Informe o nome do observador'),
  species:                   z.string().min(1, 'Selecione a espécie'),
  alive_count:               z.number().int().min(0),
  dead_count:                z.number().int().min(0),
  dormant_count:             z.number().int().min(0),
  natural_recovery_count:    z.number().int().min(0).optional(),
  natural_recovery_species:  z.string().optional(),
  salinity:                  z.number().min(0).optional(),
  crab_burrows:              z.number().int().min(0).optional(),
  // Growth fields (hidden for 3_months stage)
  height_cm:                 z.number().positive().optional(),
  stem_diameter_mm:          z.number().positive().optional(),
  leaf_count:                z.number().int().min(0).optional(),
  notes:                     z.string().optional(),
});
type FormData = z.infer<typeof formSchema>;

export default function MonitoringFormScreen({ route, navigation }: Props) {
  const { taskId, samplePointId, samplePointLabel, taskStage, availableSpecies } = route.params ?? {};
  const createForm = useCreateMonitoringForm();
  const [localFormId]   = useState<string>(`form-draft-${Date.now()}`);
  const [photosReady, setPhotosReady] = useState(false);
  const showGrowthFields = taskStage !== '3_months';

  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      alive_count:   0,
      dead_count:    0,
      dormant_count: 0,
    },
  });

  const onSubmit = async (data: FormData) => {
    if (!photosReady) {
      Alert.alert(
        'Fotos obrigatórias',
        'São necessárias 1 fotoponto + 10 fotos de borda para finalizar o formulário.',
        [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Salvar rascunho', onPress: () => save(data, 'draft') },
        ]
      );
      return;
    }
    await save(data, 'completed');
  };

  const save = async (data: FormData, formStatus: 'draft' | 'completed') => {
    try {
      await createForm.mutateAsync({
        task_id:                  taskId,
        sample_point_id:          samplePointId,
        observer_name:            data.observer_name,
        observed_at:              Date.now(),
        species:                  data.species,
        alive_count:              data.alive_count,
        dead_count:               data.dead_count,
        dormant_count:            data.dormant_count,
        natural_recovery_count:   data.natural_recovery_count,
        natural_recovery_species: data.natural_recovery_species,
        salinity:                 data.salinity,
        crab_burrows:             data.crab_burrows,
        height_cm:                showGrowthFields ? data.height_cm : undefined,
        stem_diameter_mm:         showGrowthFields ? data.stem_diameter_mm : undefined,
        leaf_count:               showGrowthFields ? data.leaf_count : undefined,
        notes:                    data.notes,
        form_status:              formStatus,
      });
      navigation.goBack();
    } catch {
      Alert.alert('Erro', 'Não foi possível salvar o formulário. Tente novamente.');
    }
  };

  const speciesItems = (availableSpecies ?? []).map((sp: string) => ({
    label: sp, value: sp,
  }));

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <OfflineBanner />
      <ScrollView style={theme.screen} contentContainerStyle={theme.scrollContent}>

        {samplePointLabel && (
          <View style={s.pointHeader}>
            <Text style={s.pointLabel}>Ponto: {samplePointLabel}</Text>
          </View>
        )}

        {/* Observer */}
        <Text style={theme.sectionLabel}>Observador</Text>
        <Text style={theme.fieldLabel}>Nome *</Text>
        <Controller name="observer_name" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={[theme.input, errors.observer_name && theme.inputError]}
              placeholder="Nome do observador de campo"
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
            />
          )}
        />
        {errors.observer_name && <Text style={theme.fieldError}>{errors.observer_name.message}</Text>}

        {/* Species */}
        <Text style={theme.sectionLabel}>Espécie</Text>
        <Text style={theme.fieldLabel}>Espécie observada *</Text>
        <Controller name="species" control={control}
          render={({ field: { onChange, value } }) => (
            speciesItems.length > 0 ? (
              <RNPickerSelect
                placeholder={{ label: '— selecionar espécie —', value: null }}
                items={speciesItems}
                onValueChange={onChange}
                value={value ?? null}
                style={{ inputIOS: theme.input, inputAndroid: theme.input }}
              />
            ) : (
              <TextInput
                style={[theme.input, errors.species && theme.inputError]}
                placeholder="Nome da espécie"
                value={value ?? ''}
                onChangeText={onChange}
              />
            )
          )}
        />
        {errors.species && <Text style={theme.fieldError}>{errors.species.message}</Text>}

        {/* Counts */}
        <Text style={theme.sectionLabel}>Contagem de Mudas</Text>
        <Controller name="alive_count" control={control}
          render={({ field: { onChange, value } }) => (
            <CounterField label="Vivas" value={value ?? 0} onChange={onChange} />
          )}
        />
        <Controller name="dead_count" control={control}
          render={({ field: { onChange, value } }) => (
            <CounterField label="Mortas" value={value ?? 0} onChange={onChange} />
          )}
        />
        <Controller name="dormant_count" control={control}
          render={({ field: { onChange, value } }) => (
            <CounterField label="Dormentes" value={value ?? 0} onChange={onChange} />
          )}
        />

        {/* Recovery */}
        <Text style={theme.sectionLabel}>Recuperação Natural</Text>
        <Controller name="natural_recovery_count" control={control}
          render={({ field: { onChange, value } }) => (
            <CounterField label="Regenerantes naturais" value={value ?? 0} onChange={onChange} />
          )}
        />
        <Text style={theme.fieldLabel}>Espécie regenerante</Text>
        <Controller name="natural_recovery_species" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={theme.input}
              placeholder="Espécie identificada (opcional)"
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
            />
          )}
        />

        {/* Environmental */}
        <Text style={theme.sectionLabel}>Dados Ambientais</Text>
        <View style={s.row2}>
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Salinidade (ppt)</Text>
            <Controller name="salinity" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  keyboardType="decimal-pad"
                  placeholder="ex: 15.3"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
          <View style={{ width: 10 }} />
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Tocas de caranguejo</Text>
            <Controller name="crab_burrows" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  keyboardType="number-pad"
                  placeholder="ex: 5"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseInt(t, 10) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
        </View>

        {/* Growth fields — hidden for 3_months stage */}
        {showGrowthFields && (
          <>
            <Text style={theme.sectionLabel}>Crescimento</Text>
            <View style={s.row2}>
              <View style={{ flex: 1 }}>
                <Text style={theme.fieldLabel}>Altura (cm)</Text>
                <Controller name="height_cm" control={control}
                  render={({ field: { onChange, value, onBlur } }) => (
                    <TextInput
                      style={theme.input}
                      keyboardType="decimal-pad"
                      placeholder="ex: 45.2"
                      value={value != null ? String(value) : ''}
                      onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                      onBlur={onBlur}
                    />
                  )}
                />
              </View>
              <View style={{ width: 10 }} />
              <View style={{ flex: 1 }}>
                <Text style={theme.fieldLabel}>Diâmetro do caule (mm)</Text>
                <Controller name="stem_diameter_mm" control={control}
                  render={({ field: { onChange, value, onBlur } }) => (
                    <TextInput
                      style={theme.input}
                      keyboardType="decimal-pad"
                      placeholder="ex: 8.4"
                      value={value != null ? String(value) : ''}
                      onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                      onBlur={onBlur}
                    />
                  )}
                />
              </View>
            </View>
            <Text style={theme.fieldLabel}>Número de folhas</Text>
            <Controller name="leaf_count" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  keyboardType="number-pad"
                  placeholder="ex: 12"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseInt(t, 10) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </>
        )}

        {/* Notes */}
        <Text style={theme.sectionLabel}>Observações</Text>
        <Controller name="notes" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={[theme.input, s.textarea]}
              placeholder="Observações adicionais..."
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
              multiline
              numberOfLines={3}
              textAlignVertical="top"
            />
          )}
        />

        {/* Photos — 1 fotoponto + 10 borda */}
        <Text style={theme.sectionLabel}>Fotos de Campo (obrigatório)</Text>
        <FotoPontoSection formId={localFormId} onChange={setPhotosReady} />

        {/* Submit */}
        <TouchableOpacity
          style={[theme.primaryBtn, { marginTop: 20 }, isSubmitting && { opacity: 0.6 }]}
          onPress={handleSubmit(onSubmit)}
          disabled={isSubmitting}
        >
          {isSubmitting
            ? <ActivityIndicator color="#fff" />
            : <Text style={theme.primaryBtnText}>
                {photosReady ? 'Concluir Formulário' : 'Salvar Rascunho'}
              </Text>}
        </TouchableOpacity>

        <TouchableOpacity style={theme.secondaryBtn} onPress={() => navigation.goBack()}>
          <Text style={theme.secondaryBtnText}>Cancelar</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  pointHeader:  { backgroundColor: colors.sage, borderRadius: 9, paddingHorizontal: 12, paddingVertical: 8, marginBottom: 12 },
  pointLabel:   { fontSize: 13, fontWeight: '700', color: colors.green },
  row2:         { flexDirection: 'row', alignItems: 'flex-start' },
  textarea:     { height: 80, paddingTop: 10 },
});
