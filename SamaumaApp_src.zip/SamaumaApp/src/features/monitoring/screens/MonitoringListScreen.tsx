import React from 'react';
import {
  View, Text, FlatList, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useTasksForSession } from '../hooks/useMonitoringTasks';
import OfflineBanner from '../../../components/OfflineBanner';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import type { ApiMonitoringTask } from '../../../services/api';
import { STAGE_LABELS } from '../../../models/MonitoringTask';

const STATUS_COLORS: Record<string, string> = {
  pending:     colors.terracotta,
  in_progress: '#2563eb',
  completed:   '#16a34a',
  overdue:     '#dc2626',
};

const STATUS_LABELS: Record<string, string> = {
  pending:     'Pendente',
  in_progress: 'Em andamento',
  completed:   'Concluído',
  overdue:     'Atrasado',
};

export default function MonitoringListScreen({ route, navigation }: any) {
  const { sessionId, sessionName } = route.params;
  const { data: tasks, isLoading, refetch, isRefetching } = useTasksForSession(sessionId);

  return (
    <View style={theme.screen}>
      <OfflineBanner />
      {isLoading ? (
        <View style={s.center}>
          <ActivityIndicator color={colors.terracotta} size="large" />
        </View>
      ) : (
        <FlatList
          data={tasks ?? []}
          keyExtractor={(item: ApiMonitoringTask) => String(item.id)}
          contentContainerStyle={theme.scrollContent}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={refetch}
              tintColor={colors.terracotta}
            />
          }
          ListHeaderComponent={
            sessionName ? (
              <Text style={s.sessionHeader}>{sessionName}</Text>
            ) : null
          }
          renderItem={({ item: task }) => {
            const statusColor = STATUS_COLORS[task.status] ?? colors.terracotta;
            const formsCount  = task.forms?.length ?? 0;
            const isOverdue   = task.status === 'overdue';
            return (
              <TouchableOpacity
                style={[s.card, isOverdue && s.cardOverdue]}
                onPress={() => navigation.navigate('Tarefa', { taskId: String(task.id) })}
                activeOpacity={0.85}
              >
                <View style={s.cardTop}>
                  <Text style={s.stageLabel}>
                    {STAGE_LABELS[task.stage] ?? task.stage}
                  </Text>
                  <View style={[s.statusBadge, { backgroundColor: statusColor + '22' }]}>
                    <Text style={[s.statusText, { color: statusColor }]}>
                      {STATUS_LABELS[task.status] ?? task.status}
                    </Text>
                  </View>
                </View>
                <Text style={s.dueDate}>
                  Prazo: {new Date(task.due_date).toLocaleDateString('pt-BR')}
                </Text>
                {formsCount > 0 && (
                  <Text style={s.formsCount}>{formsCount} formulário(s) preenchido(s)</Text>
                )}
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={
            <View style={s.center}>
              <Text style={s.empty}>Nenhuma tarefa de monitoramento.</Text>
              <Text style={s.emptySub}>As tarefas são geradas automaticamente após o plantio.</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  sessionHeader:{ fontSize: 13, fontWeight: '700', color: colors.brown, marginBottom: 12 },
  card:         { backgroundColor: colors.white, borderRadius: 12, padding: 14, marginBottom: 9, borderLeftWidth: 3, borderLeftColor: colors.terracotta, shadowColor: colors.brown, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 2 },
  cardOverdue:  { borderLeftColor: '#dc2626' },
  cardTop:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  stageLabel:   { fontSize: 14, fontWeight: '700', color: colors.brown },
  statusBadge:  { borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
  statusText:   { fontSize: 10, fontWeight: '700' },
  dueDate:      { fontSize: 11, color: '#888' },
  formsCount:   { fontSize: 11, color: colors.green, fontWeight: '700', marginTop: 4 },
  empty:        { fontSize: 14, color: '#aaa', fontWeight: '700', marginBottom: 6, textAlign: 'center' },
  emptySub:     { fontSize: 11, color: '#bbb', textAlign: 'center', paddingHorizontal: 20 },
});
