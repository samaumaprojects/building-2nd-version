import React from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator, Alert,
} from 'react-native';
import { useTask, useUpdateTaskStatus } from '../hooks/useMonitoringTasks';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import { STAGE_LABELS } from '../../../models/MonitoringTask';
import OfflineBanner from '../../../components/OfflineBanner';
import type { ApiMonitoringForm } from '../../../services/api';

const STATUS_COLORS: Record<string, string> = {
  pending:     colors.terracotta,
  in_progress: '#2563eb',
  completed:   '#16a34a',
  overdue:     '#dc2626',
};

const STATUS_LABELS: Record<string, string> = {
  pending:     'Pendente',
  in_progress: 'Em andamento',
  completed:   'Concluído',
  overdue:     'Atrasado',
};

export default function TaskDetailScreen({ route, navigation }: any) {
  const { taskId } = route.params ?? {};
  const { data: task, isLoading } = useTask(taskId);
  const updateStatus = useUpdateTaskStatus(taskId);

  if (isLoading) {
    return (
      <View style={[theme.screen, s.center]}>
        <ActivityIndicator color={colors.terracotta} size="large" />
      </View>
    );
  }

  if (!task) {
    return (
      <View style={[theme.screen, s.center]}>
        <Text style={s.errorText}>Tarefa não encontrada.</Text>
      </View>
    );
  }

  const forms = task.forms ?? [];
  const statusColor = STATUS_COLORS[task.status] ?? colors.terracotta;
  const canStartForm = task.status !== 'completed';

  const handleMarkInProgress = () => {
    if (task.status !== 'pending') return;
    Alert.alert('Iniciar monitoramento?', '', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Iniciar', onPress: () => updateStatus.mutate('in_progress') },
    ]);
  };

  return (
    <ScrollView style={theme.screen} contentContainerStyle={theme.scrollContent}>
      <OfflineBanner />

      {/* Task header */}
      <View style={s.headerCard}>
        <Text style={s.stageName}>{STAGE_LABELS[task.stage] ?? task.stage}</Text>
        <View style={[s.statusBadge, { backgroundColor: statusColor + '22' }]}>
          <Text style={[s.statusText, { color: statusColor }]}>
            {STATUS_LABELS[task.status] ?? task.status}
          </Text>
        </View>
        <Text style={s.dueDate}>
          Prazo: {new Date(task.due_date).toLocaleDateString('pt-BR')}
        </Text>
      </View>

      {/* Stats */}
      <View style={s.statsRow}>
        <View style={s.statBox}>
          <Text style={s.statValue}>{forms.length}</Text>
          <Text style={s.statKey}>Formulários</Text>
        </View>
        <View style={s.statBox}>
          <Text style={s.statValue}>
            {forms.filter((f: ApiMonitoringForm) => f.form_status === 'completed').length}
          </Text>
          <Text style={s.statKey}>Concluídos</Text>
        </View>
        <View style={s.statBox}>
          <Text style={s.statValue}>
            {forms.reduce((sum: number, f: ApiMonitoringForm) => sum + (f.alive_count ?? 0), 0)}
          </Text>
          <Text style={s.statKey}>Mudas vivas</Text>
        </View>
      </View>

      {/* Action buttons */}
      {canStartForm && (
        <>
          <Text style={theme.sectionLabel}>Ações</Text>
          {task.status === 'pending' && (
            <TouchableOpacity style={s.startBtn} onPress={handleMarkInProgress} activeOpacity={0.85}>
              <Text style={s.startBtnText}>Iniciar Monitoramento</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[theme.primaryBtn]}
            onPress={() => navigation.navigate('Formulario', {
              taskId,
              taskStage: task.stage,
              availableSpecies: (task.session?.species_counts ?? []).map((sc: any) => sc.species),
            })}
            activeOpacity={0.85}
          >
            <Text style={theme.primaryBtnText}>+ Novo Formulário de Campo</Text>
          </TouchableOpacity>
        </>
      )}

      {/* Existing forms */}
      {forms.length > 0 && (
        <>
          <Text style={theme.sectionLabel}>Formulários registrados ({forms.length})</Text>
          {forms.map((form: ApiMonitoringForm) => (
            <View key={form.id} style={s.formCard}>
              <View style={s.formCardTop}>
                <Text style={s.formSpecies}>{form.species}</Text>
                <View style={[s.formStatusBadge, {
                  backgroundColor: form.form_status === 'completed'
                    ? '#16a34a22' : colors.terracotta + '22',
                }]}>
                  <Text style={[s.formStatusText, {
                    color: form.form_status === 'completed' ? '#16a34a' : colors.terracotta,
                  }]}>
                    {form.form_status === 'completed' ? 'Concluído' : 'Rascunho'}
                  </Text>
                </View>
              </View>
              <View style={s.formCounts}>
                <Text style={s.countItem}>V: {form.alive_count}</Text>
                <Text style={[s.countItem, { color: '#dc2626' }]}>M: {form.dead_count}</Text>
                <Text style={[s.countItem, { color: '#d97706' }]}>D: {form.dormant_count}</Text>
                {form.natural_recovery_count != null && form.natural_recovery_count > 0 && (
                  <Text style={[s.countItem, { color: '#16a34a' }]}>R: {form.natural_recovery_count}</Text>
                )}
              </View>
              <Text style={s.formDate}>
                {new Date(form.observed_at).toLocaleDateString('pt-BR')} · {form.observer_name}
              </Text>
              {form.notes ? (
                <Text style={s.formNotes} numberOfLines={2}>{form.notes}</Text>
              ) : null}
            </View>
          ))}
        </>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  center:         { alignItems: 'center', justifyContent: 'center' },
  errorText:      { color: '#aaa', fontSize: 14 },
  headerCard:     { backgroundColor: colors.white, borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: colors.brown, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 2 },
  stageName:      { fontSize: 18, fontWeight: '700', color: colors.brown, marginBottom: 8 },
  statusBadge:    { alignSelf: 'flex-start', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, marginBottom: 8 },
  statusText:     { fontSize: 11, fontWeight: '700' },
  dueDate:        { fontSize: 12, color: '#888' },
  statsRow:       { flexDirection: 'row', gap: 8, marginBottom: 12 },
  statBox:        { flex: 1, backgroundColor: colors.white, borderRadius: 10, padding: 10, alignItems: 'center', shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  statValue:      { fontSize: 17, fontWeight: '700', color: colors.brown },
  statKey:        { fontSize: 8, color: '#888', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 1 },
  startBtn:       { backgroundColor: colors.green, borderRadius: 10, paddingVertical: 12, alignItems: 'center', marginBottom: 8 },
  startBtnText:   { color: '#fff', fontWeight: '700', fontSize: 13 },
  formCard:       { backgroundColor: colors.white, borderRadius: 12, padding: 12, marginBottom: 8, shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  formCardTop:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  formSpecies:    { fontSize: 13, fontWeight: '700', color: colors.brown, flex: 1 },
  formStatusBadge:{ borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  formStatusText: { fontSize: 10, fontWeight: '700' },
  formCounts:     { flexDirection: 'row', gap: 12, marginBottom: 4 },
  countItem:      { fontSize: 13, fontWeight: '700', color: colors.green },
  formDate:       { fontSize: 10, color: '#888', marginBottom: 2 },
  formNotes:      { fontSize: 11, color: '#666', fontStyle: 'italic' },
});
