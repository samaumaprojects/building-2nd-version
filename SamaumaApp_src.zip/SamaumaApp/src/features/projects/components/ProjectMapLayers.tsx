import React from 'react';
import Mapbox from '@rnmapbox/maps';
import { colors } from '../../../constants/colors';

interface Props {
  projectPolygon?: object | null;
  sessions:        Array<{ id: string; polygon?: object | null; name: string }>;
  samplePoints?:   Array<{ id: string; latitude: number; longitude: number; label: string }>;
  onPinPress?:     (pointId: string) => void;
}

export default function ProjectMapLayers({ projectPolygon, sessions, samplePoints = [], onPinPress }: Props) {
  const projectFeature = projectPolygon ? {
    type: 'Feature', geometry: projectPolygon, properties: {},
  } : null;

  const sessionsFC = {
    type: 'FeatureCollection',
    features: sessions
      .filter(s => !!s.polygon)
      .map((s, i) => ({
        type: 'Feature',
        geometry: s.polygon,
        properties: { id: s.id, name: s.name, index: i },
      })),
  };

  const pointsFC = {
    type: 'FeatureCollection',
    features: samplePoints.map(p => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [p.longitude, p.latitude] },
      properties: { id: p.id, label: p.label },
    })),
  };

  return (
    <>
      {/* Polígono do projeto — contorno tracejado verde */}
      {projectFeature && (
        <Mapbox.ShapeSource id="projectSource" shape={projectFeature as any}>
          <Mapbox.FillLayer id="projectFill"
            style={{ fillColor: colors.green, fillOpacity: 0.12 }}
          />
          <Mapbox.LineLayer id="projectLine"
            style={{ lineColor: colors.green, lineWidth: 2, lineDasharray: [4, 3] }}
          />
        </Mapbox.ShapeSource>
      )}

      {/* Sessões de plantio — preenchidas em laranja */}
      <Mapbox.ShapeSource id="sessionsSource" shape={sessionsFC as any}>
        <Mapbox.FillLayer id="sessionsFill"
          style={{ fillColor: colors.terracotta, fillOpacity: 0.35 }}
        />
        <Mapbox.LineLayer id="sessionsLine"
          style={{ lineColor: colors.terracotta, lineWidth: 1.5 }}
        />
      </Mapbox.ShapeSource>

      {/* Pontos amostrais — círculos azuis com label */}
      {samplePoints.length > 0 && (
        <Mapbox.ShapeSource
          id="pointsSource"
          shape={pointsFC as any}
          onPress={(e) => {
            const id = e.features[0]?.properties?.id;
            if (id && onPinPress) onPinPress(id);
          }}
        >
          <Mapbox.CircleLayer id="pointsCircle"
            style={{ circleColor: '#4a80c4', circleRadius: 9, circleStrokeWidth: 2, circleStrokeColor: '#fff' }}
          />
          <Mapbox.SymbolLayer id="pointsLabel"
            style={{ textField: ['get', 'label'], textSize: 10, textColor: '#fff', textFont: ['DIN Pro Bold'], textAnchor: 'center' }}
          />
        </Mapbox.ShapeSource>
      )}
    </>
  );
}
