import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { Q } from '@nozbe/watermelondb';
import api from '../../../services/api';
import { database, collections } from '../../../models/database';
import type { ApiProject } from '../../../services/api';

export function useProjects() {
  const query = useQuery({
    queryKey: ['projects'],
    queryFn: async () => {
      const { data } = await api.get<ApiProject[]>('/projects');
      return data;
    },
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (query.data) syncProjectsToLocal(query.data);
  }, [query.data]);

  return query;
}

export function useProject(id: string) {
  return useQuery({
    queryKey: ['projects', id],
    queryFn: async () => {
      const { data } = await api.get<ApiProject>(`/projects/${id}`);
      return data;
    },
    enabled: !!id,
  });
}

export function useCreateProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: Partial<ApiProject>) =>
      api.post<ApiProject>('/projects', payload).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['projects'] });
    },
  });
}

export function useUpdateProject(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: Partial<ApiProject>) =>
      api.put(`/projects/${id}`, payload).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['projects'] });
      qc.invalidateQueries({ queryKey: ['projects', id] });
    },
  });
}

export function useDeleteProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      api.delete(`/projects/${id}`).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['projects'] });
    },
  });
}

async function syncProjectsToLocal(projects: ApiProject[]) {
  await database.write(async () => {
    for (const p of projects) {
      const existing = await collections.projects()
        .query(Q.where('remote_id', String(p.id))).fetch();
      if (existing.length > 0) {
        await existing[0].update(r => {
          r.name             = p.name;
          r.description      = p.description ?? null;
          r.state            = p.state ?? null;
          r.municipality     = p.municipality ?? null;
          r.startDate        = p.start_date;
          r.endDate          = p.end_date ?? null;
          r.fieldLeaderId    = p.field_leader_id ?? null;
          r.speciesJson      = p.species ? JSON.stringify(p.species) : null;
          r.methodologiesJson = p.methodologies ? JSON.stringify(p.methodologies) : null;
          r.conditionsJson   = p.conditions ? JSON.stringify(p.conditions) : null;
          r.polygonJson      = p.polygon ? JSON.stringify(p.polygon) : null;
          r.status           = p.status;
          r.synced           = true;
        });
      } else {
        await collections.projects().create(r => {
          r.remoteId         = String(p.id);
          r.name             = p.name;
          r.description      = p.description ?? null;
          r.state            = p.state ?? null;
          r.municipality     = p.municipality ?? null;
          r.startDate        = p.start_date;
          r.endDate          = p.end_date ?? null;
          r.fieldLeaderId    = p.field_leader_id ?? null;
          r.speciesJson      = p.species ? JSON.stringify(p.species) : null;
          r.methodologiesJson = p.methodologies ? JSON.stringify(p.methodologies) : null;
          r.conditionsJson   = p.conditions ? JSON.stringify(p.conditions) : null;
          r.polygonJson      = p.polygon ? JSON.stringify(p.polygon) : null;
          r.status           = p.status;
          r.synced           = true;
        });
      }
    }
  });
}
