import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { Q } from '@nozbe/watermelondb';
import api from '../../../services/api';
import { database, collections } from '../../../models/database';
import type { ApiSponsor } from '../../../services/api';

export function useSponsors(projectId: string) {
  const query = useQuery({
    queryKey: ['sponsors', projectId],
    queryFn: async () => {
      const { data } = await api.get<ApiSponsor[]>(`/projects/${projectId}/sponsors`);
      return data;
    },
    enabled: !!projectId,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (query.data) syncSponsorsToLocal(query.data, projectId);
  }, [query.data]);

  return query;
}

export function useCreateSponsor(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: Partial<ApiSponsor>) =>
      api.post<ApiSponsor>(`/projects/${projectId}/sponsors`, payload).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sponsors', projectId] });
    },
  });
}

export function useUpdateSponsor(sponsorId: string, projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: Partial<ApiSponsor>) =>
      api.put(`/sponsors/${sponsorId}`, payload).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sponsors', projectId] });
    },
  });
}

export function useDeleteSponsor(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (sponsorId: string) =>
      api.delete(`/sponsors/${sponsorId}`).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sponsors', projectId] });
    },
  });
}

async function syncSponsorsToLocal(sponsors: ApiSponsor[], projectId: string) {
  await database.write(async () => {
    for (const s of sponsors) {
      const existing = await collections.sponsors()
        .query(Q.where('remote_id', String(s.id))).fetch();
      if (existing.length > 0) {
        await existing[0].update(r => {
          r.name         = s.name;
          r.contractRef  = s.contract_ref ?? null;
          r.type         = s.type ?? null;
          r.status       = s.status;
          r.targetTrees  = s.target_trees ?? null;
          r.plantedTrees = s.planted_trees ?? 0;
          r.synced       = true;
        });
      } else {
        await collections.sponsors().create(r => {
          r.remoteId     = String(s.id);
          r.projectId    = projectId;
          r.name         = s.name;
          r.contractRef  = s.contract_ref ?? null;
          r.type         = s.type ?? null;
          r.status       = s.status;
          r.targetTrees  = s.target_trees ?? null;
          r.plantedTrees = s.planted_trees ?? 0;
          r.synced       = true;
        });
      }
    }
  });
}
