import React from 'react';
import {
  View, Text, ScrollView, TextInput, TouchableOpacity,
  StyleSheet, Alert, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import RNPickerSelect from 'react-native-picker-select';
import { useCreateProject } from '../hooks/useProjects';
import OfflineBanner from '../../../components/OfflineBanner';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';

const projectSchema = z.object({
  name:         z.string().min(2, 'Informe o nome do projeto'),
  description:  z.string().optional(),
  state:        z.string().optional(),
  municipality: z.string().optional(),
  start_date:   z.string().min(1, 'Informe a data de início'),
  end_date:     z.string().optional(),
  status:       z.enum(['active', 'paused', 'completed']),
});
type ProjectForm = z.infer<typeof projectSchema>;

export default function CriarProjetoScreen({ navigation }: any) {
  const criar = useCreateProject();

  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<ProjectForm>({
    resolver: zodResolver(projectSchema),
    defaultValues: { status: 'active' },
  });

  const onSubmit = async (data: ProjectForm) => {
    try {
      await criar.mutateAsync({
        name:         data.name,
        description:  data.description,
        state:        data.state,
        municipality: data.municipality,
        start_date:   data.start_date,
        end_date:     data.end_date || undefined,
        status:       data.status,
      });
      navigation.goBack();
    } catch (e: any) {
      const msg = e?.response?.data?.message ?? 'Não foi possível criar o projeto.';
      Alert.alert('Erro', msg);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <OfflineBanner />
      <ScrollView style={theme.screen} contentContainerStyle={theme.scrollContent}>

        <Text style={theme.sectionLabel}>Dados do Projeto</Text>

        <Text style={theme.fieldLabel}>Nome *</Text>
        <Controller name="name" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={[theme.input, errors.name && theme.inputError]}
              placeholder="Nome do projeto de reflorestamento"
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
              autoCapitalize="words"
            />
          )}
        />
        {errors.name && <Text style={theme.fieldError}>{errors.name.message}</Text>}

        <Text style={theme.fieldLabel}>Descrição</Text>
        <Controller name="description" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={[theme.input, s.textarea]}
              placeholder="Objetivo, localização, ecossistema alvo..."
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          )}
        />

        <View style={s.row2}>
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Município</Text>
            <Controller name="municipality" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  placeholder="ex: São Luís"
                  value={value ?? ''}
                  onChangeText={onChange}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
          <View style={{ width: 10 }} />
          <View style={{ flex: 0.6 }}>
            <Text style={theme.fieldLabel}>Estado</Text>
            <Controller name="state" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  placeholder="ex: MA"
                  value={value ?? ''}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  autoCapitalize="characters"
                  maxLength={2}
                />
              )}
            />
          </View>
        </View>

        <Text style={theme.sectionLabel}>Cronograma</Text>

        <View style={s.row2}>
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Data de Início *</Text>
            <Controller name="start_date" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={[theme.input, errors.start_date && theme.inputError]}
                  placeholder="AAAA-MM-DD"
                  value={value ?? ''}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  keyboardType="numbers-and-punctuation"
                />
              )}
            />
            {errors.start_date && (
              <Text style={theme.fieldError}>{errors.start_date.message}</Text>
            )}
          </View>
          <View style={{ width: 10 }} />
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Previsão de Fim</Text>
            <Controller name="end_date" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  placeholder="AAAA-MM-DD"
                  value={value ?? ''}
                  onChangeText={onChange}
                  onBlur={onBlur}
                  keyboardType="numbers-and-punctuation"
                />
              )}
            />
          </View>
        </View>

        <Text style={theme.sectionLabel}>Status</Text>
        <Controller name="status" control={control}
          render={({ field: { onChange, value } }) => (
            <RNPickerSelect
              items={[
                { label: 'Ativo',     value: 'active' },
                { label: 'Pausado',   value: 'paused' },
                { label: 'Concluído', value: 'completed' },
              ]}
              onValueChange={onChange}
              value={value}
              style={{ inputIOS: theme.input, inputAndroid: theme.input }}
            />
          )}
        />

        <TouchableOpacity
          style={[theme.primaryBtn, { marginTop: 24 }, isSubmitting && { opacity: 0.6 }]}
          onPress={handleSubmit(onSubmit)}
          disabled={isSubmitting}
        >
          {isSubmitting
            ? <ActivityIndicator color="#fff" />
            : <Text style={theme.primaryBtnText}>Criar Projeto</Text>}
        </TouchableOpacity>

        <TouchableOpacity style={theme.secondaryBtn} onPress={() => navigation.goBack()}>
          <Text style={theme.secondaryBtnText}>Cancelar</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  row2:    { flexDirection: 'row', alignItems: 'flex-start' },
  textarea:{ height: 90, paddingTop: 10 },
});
