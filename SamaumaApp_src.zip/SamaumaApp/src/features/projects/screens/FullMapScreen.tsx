import React from 'react';
import { View, StyleSheet } from 'react-native';
import Mapbox from '@rnmapbox/maps';
import MapboxMap from '../../../components/MapboxMap';
import OfflineBanner from '../../../components/OfflineBanner';
import { useProject } from '../hooks/useProjects';
import { colors } from '../../../constants/colors';
import type { ApiPlantingSession } from '../../../services/api';

function SessionPolygon({ session }: { session: ApiPlantingSession }) {
  if (!session.polygon) return null;

  let shape: any;
  try {
    const poly = session.polygon as any;
    shape = poly?.type === 'Feature'
      ? poly
      : { type: 'Feature', geometry: poly, properties: { name: session.name } };
    if (!shape.properties) shape.properties = { name: session.name };
    else shape.properties.name = session.name;
  } catch {
    return null;
  }

  return (
    <Mapbox.ShapeSource id={`session-${session.id}`} shape={shape}>
      <Mapbox.FillLayer
        id={`fill-${session.id}`}
        style={{ fillColor: colors.terracotta, fillOpacity: 0.28 }}
      />
      <Mapbox.LineLayer
        id={`line-${session.id}`}
        style={{ lineColor: colors.terracotta, lineWidth: 2.5 }}
      />
      <Mapbox.SymbolLayer
        id={`label-${session.id}`}
        style={{
          textField: ['get', 'name'],
          textSize: 12,
          textColor: colors.cream,
          textHaloColor: colors.brown,
          textHaloWidth: 1.5,
        }}
      />
    </Mapbox.ShapeSource>
  );
}

export default function FullMapScreen({ route }: any) {
  const { projectId } = route.params ?? {};
  const { data: project } = useProject(projectId);

  const sessions = project?.sessions ?? [];

  // Center on first session polygon, otherwise default to Maranhão
  const center: [number, number] = (() => {
    for (const s of sessions) {
      if (s.polygon) {
        try {
          const poly = s.polygon as any;
          const coords = poly?.geometry?.coordinates?.[0]?.[0] ?? poly?.coordinates?.[0]?.[0];
          if (coords) return [coords[0], coords[1]];
        } catch {}
      }
    }
    return [-44.42, -2.40];
  })();

  // Also show project-level polygon if present
  const projectShape: any = project?.polygon
    ? (() => {
        try {
          const p = project.polygon as any;
          return p?.type === 'Feature' ? p : { type: 'Feature', geometry: p, properties: {} };
        } catch { return null; }
      })()
    : null;

  return (
    <View style={s.container}>
      <OfflineBanner />
      <MapboxMap center={center} zoom={13} style={{ flex: 1 }}>
        {projectShape && (
          <Mapbox.ShapeSource id="project-boundary" shape={projectShape}>
            <Mapbox.FillLayer
              id="project-fill"
              style={{ fillColor: colors.green, fillOpacity: 0.08 }}
            />
            <Mapbox.LineLayer
              id="project-line"
              style={{ lineColor: colors.green, lineWidth: 1.5, lineDasharray: [4, 3] }}
            />
          </Mapbox.ShapeSource>
        )}
        {sessions.map(session => (
          <SessionPolygon key={session.id} session={session} />
        ))}
      </MapboxMap>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
});
