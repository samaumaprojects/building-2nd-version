import React from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  ActivityIndicator, Alert,
} from 'react-native';
import { useProject, useDeleteProject } from '../hooks/useProjects';
import { useSponsors } from '../hooks/useSponsors';
import StatusBadge from '../../../components/StatusBadge';
import MapboxMap from '../../../components/MapboxMap';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import { useAuthStore } from '../../auth/authStore';
import Mapbox from '@rnmapbox/maps';

export default function ProjectDetailScreen({ route, navigation }: any) {
  const { projectId } = route.params;
  const { data: project, isLoading } = useProject(projectId);
  const { data: sponsors } = useSponsors(projectId);
  const deleteProject = useDeleteProject();
  const user = useAuthStore(s => s.user);

  if (isLoading) {
    return (
      <View style={[theme.screen, s.center]}>
        <ActivityIndicator color={colors.terracotta} size="large" />
      </View>
    );
  }

  const sessions = project?.sessions ?? [];

  const center: [number, number] = project?.polygon
    ? (() => {
        try {
          const p = project.polygon as any;
          const c = p?.geometry?.coordinates?.[0]?.[0] ?? p?.coordinates?.[0]?.[0];
          return c ? [c[0], c[1]] : [-44.42, -2.40];
        } catch { return [-44.42, -2.40]; }
      })()
    : [-44.42, -2.40];

  const handleDelete = () => {
    Alert.alert(
      'Excluir projeto',
      `Tem certeza que deseja excluir "${project?.name}"? Esta ação não pode ser desfeita.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            await deleteProject.mutateAsync(projectId);
            navigation.goBack();
          },
        },
      ],
    );
  };

  return (
    <ScrollView style={theme.screen} contentContainerStyle={theme.scrollContent}>
      {/* Mini-map */}
      <TouchableOpacity
        style={s.mapThumb}
        onPress={() => navigation.navigate('MapaCompleto', { projectId })}
        activeOpacity={0.9}
      >
        <MapboxMap center={center} zoom={12} style={{ flex: 1 }}>
          {project?.polygon && (() => {
            const poly = project.polygon as any;
            const shape = poly?.type === 'Feature' ? poly : { type: 'Feature', geometry: poly, properties: {} };
            return (
              <Mapbox.ShapeSource id="project-poly" shape={shape}>
                <Mapbox.FillLayer id="project-fill" style={{ fillColor: colors.terracotta, fillOpacity: 0.2 }} />
                <Mapbox.LineLayer id="project-line" style={{ lineColor: colors.terracotta, lineWidth: 2 }} />
              </Mapbox.ShapeSource>
            );
          })()}
        </MapboxMap>
        <View style={s.mapLabel}>
          <Text style={s.mapLabelText}>Mapa completo →</Text>
        </View>
      </TouchableOpacity>

      {/* Project header */}
      <View style={s.headerCard}>
        <View style={s.headerTop}>
          <Text style={s.projectName}>{project?.name}</Text>
          <StatusBadge status={project?.status ?? 'active'} />
        </View>
        {project?.description ? (
          <Text style={s.desc}>{project.description}</Text>
        ) : null}
        <View style={s.datesRow}>
          <Text style={s.dateChip}>
            Início: {project?.start_date
              ? new Date(project.start_date).toLocaleDateString('pt-BR')
              : '—'}
          </Text>
          {project?.end_date ? (
            <Text style={s.dateChip}>
              Previsão: {new Date(project.end_date).toLocaleDateString('pt-BR')}
            </Text>
          ) : null}
        </View>
        {(project?.municipality || project?.state) && (
          <Text style={s.location}>
            {[project.municipality, project.state].filter(Boolean).join(', ')}
          </Text>
        )}
      </View>

      {/* Stats */}
      <View style={s.statsRow}>
        {[
          { label: 'Sessões',       value: sessions.length },
          { label: 'Patrocinadores', value: sponsors?.length ?? 0 },
          { label: 'Espécies',      value: project?.species?.length ?? 0 },
        ].map(({ label, value }) => (
          <View key={label} style={s.statBox}>
            <Text style={s.statValue}>{value}</Text>
            <Text style={s.statKey}>{label}</Text>
          </View>
        ))}
      </View>

      {/* Actions */}
      <Text style={theme.sectionLabel}>Ações</Text>
      {[
        { icon: '🌱', title: 'Sessões de Plantio', sub: 'Ver e registrar áreas',     screen: 'SessoesProjeto',    params: { projectId } },
        { icon: '🗺',  title: 'Mapa Completo',       sub: 'Polígonos e áreas',         screen: 'MapaCompleto',      params: { projectId } },
        ...(user?.role === 'admin' ? [
          { icon: '✏️', title: 'Editar Projeto',     sub: 'Alterar dados do projeto',  screen: 'EditarProjeto',     params: { projectId } },
        ] : []),
      ].map(({ icon, title, sub, screen, params }) => (
        <TouchableOpacity
          key={title}
          style={s.actionRow}
          onPress={() => navigation.navigate(screen, params)}
          activeOpacity={0.8}
        >
          <Text style={s.actionIcon}>{icon}</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.actionTitle}>{title}</Text>
            <Text style={s.actionSub}>{sub}</Text>
          </View>
          <Text style={s.actionArrow}>›</Text>
        </TouchableOpacity>
      ))}

      {/* Species / Methodologies */}
      {(project?.species ?? []).length > 0 && (
        <>
          <Text style={theme.sectionLabel}>Espécies</Text>
          <View style={s.chipRow}>
            {project!.species!.map((sp, i) => (
              <View key={i} style={s.chip}>
                <Text style={s.chipText}>{sp}</Text>
              </View>
            ))}
          </View>
        </>
      )}

      {/* Sponsors */}
      {(sponsors ?? []).length > 0 && (
        <>
          <Text style={theme.sectionLabel}>Patrocinadores</Text>
          {sponsors!.map(sp => (
            <View key={sp.id} style={[theme.card, s.sponsorRow]}>
              <View style={{ flex: 1 }}>
                <Text style={s.sponsorName}>{sp.name}</Text>
                {sp.contract_ref ? <Text style={s.sponsorRef}>{sp.contract_ref}</Text> : null}
              </View>
              {sp.target_trees ? (
                <Text style={s.sponsorTrees}>
                  {(sp.planted_trees ?? 0).toLocaleString('pt-BR')}/{sp.target_trees.toLocaleString('pt-BR')} mudas
                </Text>
              ) : null}
            </View>
          ))}
        </>
      )}

      {/* Delete */}
      {user?.role === 'admin' && (
        <TouchableOpacity style={s.deleteBtn} onPress={handleDelete}>
          <Text style={s.deleteBtnText}>Excluir Projeto</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const s = StyleSheet.create({
  center:         { alignItems: 'center', justifyContent: 'center' },
  mapThumb:       { height: 160, borderRadius: 12, overflow: 'hidden', marginBottom: 12 },
  mapLabel:       { position: 'absolute', bottom: 8, right: 8, backgroundColor: colors.brown, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 },
  mapLabelText:   { color: colors.cream, fontSize: 10, fontWeight: '700' },
  headerCard:     { backgroundColor: colors.white, borderRadius: 12, padding: 14, marginBottom: 12, shadowColor: colors.brown, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 2 },
  headerTop:      { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 6 },
  projectName:    { fontSize: 16, fontWeight: '700', color: colors.brown, flex: 1, marginRight: 8 },
  desc:           { fontSize: 13, color: '#555', lineHeight: 19, marginBottom: 8 },
  datesRow:       { flexDirection: 'row', gap: 10, marginBottom: 4 },
  dateChip:       { fontSize: 10, color: '#888' },
  location:       { fontSize: 11, color: colors.terracotta, fontWeight: '700', marginTop: 4 },
  statsRow:       { flexDirection: 'row', gap: 8, marginBottom: 8 },
  statBox:        { flex: 1, backgroundColor: colors.white, borderRadius: 10, padding: 10, alignItems: 'center', shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  statValue:      { fontSize: 17, fontWeight: '700', color: colors.brown },
  statKey:        { fontSize: 8, color: '#888', textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 1 },
  actionRow:      { backgroundColor: colors.white, borderRadius: 12, padding: 12, marginBottom: 8, flexDirection: 'row', alignItems: 'center', shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  actionIcon:     { fontSize: 20, marginRight: 10 },
  actionTitle:    { fontSize: 13, fontWeight: '700', color: colors.brown },
  actionSub:      { fontSize: 10, color: '#888', marginTop: 1 },
  actionArrow:    { color: colors.terracotta, fontSize: 20, marginLeft: 8 },
  chipRow:        { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  chip:           { backgroundColor: colors.sage, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3 },
  chipText:       { fontSize: 11, fontWeight: '700', color: colors.green },
  sponsorRow:     { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  sponsorName:    { fontSize: 13, fontWeight: '700', color: colors.brown },
  sponsorRef:     { fontSize: 10, color: '#888', marginTop: 1 },
  sponsorTrees:   { fontSize: 11, color: colors.terracotta, fontWeight: '700' },
  deleteBtn:      { marginTop: 20, paddingVertical: 12, alignItems: 'center' },
  deleteBtnText:  { color: '#dc2626', fontSize: 12, fontWeight: '700' },
});
