import React from 'react';
import {
  View, Text, FlatList, TouchableOpacity,
  StyleSheet, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useProjects } from '../hooks/useProjects';
import { useAuthStore } from '../../auth/authStore';
import StatusBadge from '../../../components/StatusBadge';
import OfflineBanner from '../../../components/OfflineBanner';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import type { ApiProject } from '../../../services/api';

const STATUS_LABELS: Record<string, string> = {
  active:    'Ativo',
  paused:    'Pausado',
  completed: 'Concluído',
};

export default function ProjectListScreen({ navigation }: any) {
  const { data: projects, isLoading, refetch, isRefetching } = useProjects();
  const user = useAuthStore(s => s.user);

  return (
    <View style={theme.screen}>
      <OfflineBanner />
      {isLoading ? (
        <View style={s.center}>
          <ActivityIndicator color={colors.terracotta} size="large" />
        </View>
      ) : (
        <FlatList
          data={projects ?? []}
          keyExtractor={(item: ApiProject) => String(item.id)}
          contentContainerStyle={theme.scrollContent}
          refreshControl={
            <RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={colors.terracotta} />
          }
          ListHeaderComponent={
            <View style={s.listHeader}>
              <Text style={s.greeting}>Olá, {user?.name?.split(' ')[0]}</Text>
              <Text style={s.count}>
                {projects?.length ?? 0} projeto{(projects?.length ?? 0) !== 1 ? 's' : ''}
              </Text>
            </View>
          }
          renderItem={({ item: p }) => (
            <TouchableOpacity
              style={theme.card}
              onPress={() => navigation.navigate('DetalhesProjeto', { projectId: String(p.id) })}
              activeOpacity={0.85}
            >
              <View style={s.cardTop}>
                <Text style={s.projectName} numberOfLines={2}>{p.name}</Text>
                <StatusBadge status={p.status} />
              </View>
              {p.description ? (
                <Text style={s.projectDesc} numberOfLines={2}>{p.description}</Text>
              ) : null}
              <View style={s.bottomRow}>
                <Text style={s.dateLabel}>
                  Início: {p.start_date ? new Date(p.start_date).toLocaleDateString('pt-BR') : '—'}
                </Text>
                {p.end_date ? (
                  <Text style={s.dateLabel}>
                    Prev: {new Date(p.end_date).toLocaleDateString('pt-BR')}
                  </Text>
                ) : null}
              </View>
              {p.municipality ? (
                <Text style={s.location}>{p.municipality}{p.state ? `, ${p.state}` : ''}</Text>
              ) : null}
            </TouchableOpacity>
          )}
          ListEmptyComponent={
            <View style={s.center}>
              <Text style={s.empty}>Nenhum projeto encontrado.</Text>
            </View>
          }
        />
      )}

      {user?.role === 'admin' && (
        <TouchableOpacity
          style={s.fab}
          onPress={() => navigation.navigate('CriarProjeto')}
          activeOpacity={0.85}
        >
          <Text style={s.fabText}>+</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  center:       { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  listHeader:   { marginBottom: 16 },
  greeting:     { fontSize: 20, fontWeight: '700', color: colors.brown },
  count:        { fontSize: 12, color: '#888', marginTop: 2 },
  cardTop:      { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 4 },
  projectName:  { fontSize: 15, fontWeight: '700', color: colors.brown, flex: 1, marginRight: 8 },
  projectDesc:  { fontSize: 12, color: '#666', marginBottom: 8, lineHeight: 17 },
  bottomRow:    { flexDirection: 'row', gap: 12, marginTop: 4 },
  dateLabel:    { fontSize: 10, color: '#888' },
  location:     { fontSize: 11, color: colors.terracotta, fontWeight: '700', marginTop: 4 },
  empty:        { fontSize: 13, color: '#aaa', fontStyle: 'italic' },
  fab:          { position: 'absolute', bottom: 24, right: 20, width: 52, height: 52, borderRadius: 26, backgroundColor: colors.terracotta, alignItems: 'center', justifyContent: 'center', shadowColor: colors.terracotta, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 10, elevation: 6 },
  fabText:      { color: '#fff', fontSize: 26, lineHeight: 30, fontWeight: '300' },
});
