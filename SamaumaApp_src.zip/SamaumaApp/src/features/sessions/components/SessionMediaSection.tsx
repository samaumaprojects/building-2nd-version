import React, { useEffect, useState } from 'react';
import {
  View, Text, TouchableOpacity, Image, ScrollView,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { captureGeoPhoto, captureGeoVideo, getMediaForOwner, deleteMediaItem } from '../../../services/geoMediaService';
import { colors } from '../../../constants/colors';
import type MediaItem from '../../../models/MediaItem';

interface Props { sessionId: string; }

export default function SessionMediaSection({ sessionId }: Props) {
  const [fotos, setFotos]         = useState<MediaItem[]>([]);
  const [videos, setVideos]       = useState<MediaItem[]>([]);
  const [loadingFoto, setLFoto]   = useState(false);
  const [loadingVideo, setLVideo] = useState(false);

  useEffect(() => { loadMedia(); }, [sessionId]);

  const loadMedia = async () => {
    const all = await getMediaForOwner(sessionId, 'planting_session');
    setFotos(all.filter(m => m.mediaType === 'photo'));
    setVideos(all.filter(m => m.mediaType === 'video'));
  };

  const addFoto = async () => {
    setLFoto(true);
    await captureGeoPhoto(sessionId, 'planting_session', 'session_photo');
    setLFoto(false);
    loadMedia();
  };

  const addVideo = async () => {
    setLVideo(true);
    await captureGeoVideo(sessionId, 'planting_session');
    setLVideo(false);
    loadMedia();
  };

  const confirmDelete = (id: string, tipo: string) => {
    Alert.alert('Remover', `Remover ${tipo}?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Remover', style: 'destructive', onPress: async () => { await deleteMediaItem(id); loadMedia(); }},
    ]);
  };

  return (
    <View>
      <View style={s.header}>
        <Text style={s.sectionTitle}>Fotos ({fotos.length})</Text>
        <TouchableOpacity style={s.addBtn} onPress={addFoto} disabled={loadingFoto}>
          {loadingFoto ? <ActivityIndicator color="#fff" size="small" /> : <Text style={s.addBtnText}>+ Foto</Text>}
        </TouchableOpacity>
      </View>

      {fotos.length > 0 ? (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.strip}>
          {fotos.map(foto => (
            <TouchableOpacity
              key={foto.id}
              style={s.thumbWrap}
              onLongPress={() => confirmDelete(foto.id, 'foto')}
              activeOpacity={0.9}
            >
              <Image source={{ uri: foto.localUri }} style={s.thumb} />
              {!foto.synced && <View style={s.unsyncedDot} />}
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <Text style={s.emptyText}>Nenhuma foto ainda</Text>
      )}

      <View style={[s.header, { marginTop: 14 }]}>
        <Text style={s.sectionTitle}>Vídeos ({videos.length})</Text>
        <TouchableOpacity style={[s.addBtn, { backgroundColor: colors.green }]} onPress={addVideo} disabled={loadingVideo}>
          {loadingVideo ? <ActivityIndicator color="#fff" size="small" /> : <Text style={s.addBtnText}>+ Gravar</Text>}
        </TouchableOpacity>
      </View>

      {videos.map(video => (
        <TouchableOpacity
          key={video.id}
          style={s.videoRow}
          onLongPress={() => confirmDelete(video.id, 'vídeo')}
        >
          <Text style={s.videoIcon}>🎞</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.videoTime}>{new Date(video.takenAt).toLocaleTimeString('pt-BR')}</Text>
          </View>
          {!video.synced && <Text style={s.unsyncedLabel}>⏳</Text>}
        </TouchableOpacity>
      ))}
      {videos.length === 0 && <Text style={s.emptyText}>Nenhum vídeo ainda</Text>}
      <Text style={s.holdHint}>Pressione e segure para remover.</Text>
    </View>
  );
}

const s = StyleSheet.create({
  header:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  sectionTitle: { fontSize: 12, fontWeight: '700', color: colors.brown },
  addBtn:       { backgroundColor: colors.terracotta, borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5, minWidth: 52, alignItems: 'center' },
  addBtnText:   { color: '#fff', fontWeight: '700', fontSize: 12 },
  strip:        { flexDirection: 'row' },
  thumbWrap:    { width: 80, height: 80, borderRadius: 8, overflow: 'hidden', marginRight: 6 },
  thumb:        { width: '100%', height: '100%', resizeMode: 'cover' },
  unsyncedDot:  { position: 'absolute', top: 4, right: 4, width: 8, height: 8, borderRadius: 4, backgroundColor: '#f87171' },
  unsyncedLabel:{ fontSize: 12 },
  emptyText:    { fontSize: 11, color: '#aaa', fontStyle: 'italic', marginBottom: 6 },
  videoRow:     { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: colors.white, borderRadius: 9, padding: 10, marginBottom: 6, shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 4, elevation: 1 },
  videoIcon:    { fontSize: 22 },
  videoTime:    { fontSize: 12, fontWeight: '700', color: colors.brown },
  holdHint:     { fontSize: 10, color: '#bbb', textAlign: 'center', marginTop: 4 },
});
