import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { Q } from '@nozbe/watermelondb';
import api from '../../../services/api';
import { database, collections } from '../../../models/database';
import type { ApiPlantingSession } from '../../../services/api';

export function useSessions(projectId: string) {
  const query = useQuery({
    queryKey: ['sessions', projectId],
    queryFn: async () => {
      const { data } = await api.get<ApiPlantingSession[]>(`/projects/${projectId}/sessions`);
      return data;
    },
    enabled: !!projectId,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (query.data) syncSessionsToLocal(query.data, projectId);
  }, [query.data]);

  return query;
}

export function useCreateSession(projectId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload: {
      name:             string;
      type:             'planting' | 'replanting';
      sponsor_id?:      string;
      methodology?:     string;
      conditions?:      string;
      assessor_id?:     string;
      started_at:       number;
      species_counts?:  Array<{ species: string; count: number }>;
      total_seedlings?: number;
      area_ha?:         number;
      spacing_m?:       number;
      plantable_pct?:   number;
      polygon?:         any;
      polygon_source?:  'gps_walk' | 'manual_draw';
    }) => {
      // Offline-first: save locally first
      let localId: string | null = null;
      await database.write(async () => {
        const record = await collections.sessions().create(r => {
          r.projectId         = projectId;
          r.sponsorId         = payload.sponsor_id ?? null;
          r.name              = payload.name;
          r.type              = payload.type;
          r.methodology       = payload.methodology ?? null;
          r.conditions        = payload.conditions ?? null;
          r.assessorId        = payload.assessor_id ?? null;
          r.startedAt         = payload.started_at;
          r.speciesCountsJson = payload.species_counts ? JSON.stringify(payload.species_counts) : null;
          r.totalSeedlings    = payload.total_seedlings ?? null;
          r.areaHa            = payload.area_ha ?? null;
          r.spacingM          = payload.spacing_m ?? null;
          r.plantablePct      = payload.plantable_pct ?? null;
          r.polygonJson       = payload.polygon ? JSON.stringify(payload.polygon) : null;
          r.polygonSource     = payload.polygon_source ?? null;
          r.synced            = false;
        });
        localId = record.id;
      });

      try {
        const { data } = await api.post<ApiPlantingSession>(`/projects/${projectId}/sessions`, {
          name:            payload.name,
          type:            payload.type,
          sponsor_id:      payload.sponsor_id,
          methodology:     payload.methodology,
          conditions:      payload.conditions,
          assessor_id:     payload.assessor_id,
          started_at:      payload.started_at,
          species_counts:  payload.species_counts,
          total_seedlings: payload.total_seedlings,
          area_ha:         payload.area_ha,
          spacing_m:       payload.spacing_m,
          plantable_pct:   payload.plantable_pct,
          polygon:         payload.polygon,
          polygon_source:  payload.polygon_source,
        });
        if (localId) {
          const local = await collections.sessions().find(localId);
          await database.write(async () => {
            await local.update(r => {
              r.remoteId = String(data.id);
              r.synced   = true;
            });
          });
        }
        return data;
      } catch {
        return null;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['sessions', projectId] });
      qc.invalidateQueries({ queryKey: ['projects', projectId] });
    },
  });
}

async function syncSessionsToLocal(sessions: ApiPlantingSession[], projectId: string) {
  await database.write(async () => {
    for (const s of sessions) {
      const existing = await collections.sessions()
        .query(Q.where('remote_id', String(s.id))).fetch();
      if (existing.length > 0) {
        await existing[0].update(r => {
          r.name              = s.name;
          r.type              = s.type;
          r.methodology       = s.methodology ?? null;
          r.conditions        = s.conditions ?? null;
          r.startedAt         = s.started_at;
          r.speciesCountsJson = s.species_counts ? JSON.stringify(s.species_counts) : null;
          r.totalSeedlings    = s.total_seedlings ?? null;
          r.areaHa            = s.area_ha ?? null;
          r.spacingM          = s.spacing_m ?? null;
          r.plantablePct      = s.plantable_pct ?? null;
          r.polygonJson       = s.polygon ? JSON.stringify(s.polygon) : null;
          r.polygonSource     = s.polygon_source ?? null;
          r.synced            = true;
        });
      } else {
        await collections.sessions().create(r => {
          r.remoteId          = String(s.id);
          r.projectId         = projectId;
          r.sponsorId         = s.sponsor_id ?? null;
          r.name              = s.name;
          r.type              = s.type;
          r.methodology       = s.methodology ?? null;
          r.conditions        = s.conditions ?? null;
          r.startedAt         = s.started_at;
          r.speciesCountsJson = s.species_counts ? JSON.stringify(s.species_counts) : null;
          r.totalSeedlings    = s.total_seedlings ?? null;
          r.areaHa            = s.area_ha ?? null;
          r.spacingM          = s.spacing_m ?? null;
          r.plantablePct      = s.plantable_pct ?? null;
          r.polygonJson       = s.polygon ? JSON.stringify(s.polygon) : null;
          r.polygonSource     = s.polygon_source ?? null;
          r.synced            = true;
        });
      }
    }
  });
}
