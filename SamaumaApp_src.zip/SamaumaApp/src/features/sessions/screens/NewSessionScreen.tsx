import React from 'react';
import {
  View, Text, ScrollView, TextInput, TouchableOpacity,
  StyleSheet, Alert, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { useForm, Controller } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import RNPickerSelect from 'react-native-picker-select';
import { useCreateSession } from '../hooks/useSessions';
import OfflineBanner from '../../../components/OfflineBanner';
import SessionMediaSection from '../components/SessionMediaSection';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';

const sessionSchema = z.object({
  name:             z.string().min(1, 'Informe o nome da sessão'),
  type:             z.enum(['planting', 'replanting']),
  methodology:      z.string().optional(),
  conditions:       z.string().optional(),
  total_seedlings:  z.number().int().positive().optional(),
  area_ha:          z.number().positive().optional(),
  spacing_m:        z.number().positive().optional(),
  plantable_pct:    z.number().min(0).max(100).optional(),
});
type SessionForm = z.infer<typeof sessionSchema>;

export default function NewSessionScreen({ route, navigation }: any) {
  const { projectId, polygon, polygon_source, sessionId } = route.params ?? {};
  const createSession = useCreateSession(projectId);

  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<SessionForm>({
    resolver: zodResolver(sessionSchema),
    defaultValues: { type: 'planting' },
  });

  const onSubmit = async (data: SessionForm) => {
    try {
      await createSession.mutateAsync({
        name:            data.name,
        type:            data.type,
        methodology:     data.methodology,
        conditions:      data.conditions,
        started_at:      Date.now(),
        total_seedlings: data.total_seedlings,
        area_ha:         data.area_ha,
        spacing_m:       data.spacing_m,
        plantable_pct:   data.plantable_pct,
        polygon:         polygon ?? undefined,
        polygon_source:  polygon_source ?? undefined,
      });
      navigation.goBack();
    } catch {
      Alert.alert('Erro', 'Não foi possível salvar a sessão. Tente novamente.');
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <OfflineBanner />
      <ScrollView style={theme.screen} contentContainerStyle={theme.scrollContent}>

        <Text style={theme.sectionLabel}>Identificação</Text>

        <Text style={theme.fieldLabel}>Nome da Sessão *</Text>
        <Controller name="name" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={[theme.input, errors.name && theme.inputError]}
              placeholder="ex: Margem do Rio Norte — Jan 2025"
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
            />
          )}
        />
        {errors.name && <Text style={theme.fieldError}>{errors.name.message}</Text>}

        <Text style={theme.fieldLabel}>Tipo *</Text>
        <Controller name="type" control={control}
          render={({ field: { onChange, value } }) => (
            <RNPickerSelect
              items={[
                { label: 'Plantio',    value: 'planting' },
                { label: 'Replantio',  value: 'replanting' },
              ]}
              onValueChange={onChange}
              value={value}
              style={{ inputIOS: theme.input, inputAndroid: theme.input }}
            />
          )}
        />

        <Text style={theme.fieldLabel}>Metodologia</Text>
        <Controller name="methodology" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={theme.input}
              placeholder="ex: Nucleação, Transplante direto..."
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
            />
          )}
        />

        <Text style={theme.fieldLabel}>Condições</Text>
        <Controller name="conditions" control={control}
          render={({ field: { onChange, value, onBlur } }) => (
            <TextInput
              style={theme.input}
              placeholder="ex: Margens de rio, Solo arenoso..."
              value={value ?? ''}
              onChangeText={onChange}
              onBlur={onBlur}
            />
          )}
        />

        <Text style={theme.sectionLabel}>Dados de Campo</Text>

        <View style={s.row2}>
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Total de Mudas</Text>
            <Controller name="total_seedlings" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={[theme.input, errors.total_seedlings && theme.inputError]}
                  keyboardType="number-pad"
                  placeholder="ex: 500"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseInt(t, 10) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
          <View style={{ width: 10 }} />
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Área (ha)</Text>
            <Controller name="area_ha" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={[theme.input, errors.area_ha && theme.inputError]}
                  keyboardType="decimal-pad"
                  placeholder="ex: 2.5"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
        </View>

        <View style={s.row2}>
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Espaçamento (m)</Text>
            <Controller name="spacing_m" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  keyboardType="decimal-pad"
                  placeholder="ex: 2.0"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
          <View style={{ width: 10 }} />
          <View style={{ flex: 1 }}>
            <Text style={theme.fieldLabel}>Plantável (%)</Text>
            <Controller name="plantable_pct" control={control}
              render={({ field: { onChange, value, onBlur } }) => (
                <TextInput
                  style={theme.input}
                  keyboardType="decimal-pad"
                  placeholder="ex: 70"
                  value={value != null ? String(value) : ''}
                  onChangeText={t => onChange(t ? parseFloat(t) : undefined)}
                  onBlur={onBlur}
                />
              )}
            />
          </View>
        </View>

        <Text style={theme.sectionLabel}>Polígono da Área</Text>
        <TouchableOpacity
          style={[s.polygonBtn, polygon && s.polygonBtnDone]}
          onPress={() => navigation.navigate('RegistrarCaminho', {
            projectId,
            initialMode: 'gps_walk',
          })}
          activeOpacity={0.85}
        >
          <Text style={s.polygonIcon}>{polygon ? '✓' : '🚶'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.polygonBtnTitle}>
              {polygon ? 'Polígono registrado' : 'Registrar polígono GPS'}
            </Text>
            <Text style={s.polygonBtnSub}>
              {polygon
                ? `Fonte: ${polygon_source === 'gps_walk' ? 'GPS' : 'Manual'}`
                : 'Caminhe pela área para registrar automaticamente'}
            </Text>
          </View>
        </TouchableOpacity>

        {sessionId && (
          <>
            <Text style={theme.sectionLabel}>Mídia da Sessão</Text>
            <SessionMediaSection sessionId={sessionId} />
          </>
        )}

        <TouchableOpacity
          style={[theme.primaryBtn, { marginTop: 16 }, isSubmitting && { opacity: 0.6 }]}
          onPress={handleSubmit(onSubmit)}
          disabled={isSubmitting}
        >
          {isSubmitting
            ? <ActivityIndicator color="#fff" />
            : <Text style={theme.primaryBtnText}>Salvar Sessão</Text>}
        </TouchableOpacity>

        <TouchableOpacity style={theme.secondaryBtn} onPress={() => navigation.goBack()}>
          <Text style={theme.secondaryBtnText}>Cancelar</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  row2:           { flexDirection: 'row', alignItems: 'flex-start' },
  polygonBtn:     { backgroundColor: colors.white, borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 2, borderColor: 'rgba(209,209,167,0.7)', marginBottom: 16, shadowColor: colors.brown, shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.07, shadowRadius: 5, elevation: 1 },
  polygonBtnDone: { borderColor: colors.green, backgroundColor: 'rgba(45,122,64,0.05)' },
  polygonIcon:    { fontSize: 22, width: 30, textAlign: 'center' },
  polygonBtnTitle:{ fontSize: 13, fontWeight: '700', color: colors.brown },
  polygonBtnSub:  { fontSize: 10, color: '#888', marginTop: 2 },
});
