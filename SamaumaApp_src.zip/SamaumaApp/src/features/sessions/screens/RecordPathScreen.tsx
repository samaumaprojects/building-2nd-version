import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import Geolocation from '@react-native-community/geolocation';
import Mapbox from '@rnmapbox/maps';
import MapboxMap from '../../../components/MapboxMap';
import { rdpSimplify, closePolygon } from '../utils/pathUtils';
import { colors } from '../../../constants/colors';
import OfflineBanner from '../../../components/OfflineBanner';

type Mode = 'gps_walk' | 'manual_draw';

export default function RecordPathScreen({ navigation, route }: any) {
  const { initialMode = 'gps_walk' } = route.params ?? {};

  const [mode, setMode]             = useState<Mode>(initialMode);
  const [coords, setCoords]         = useState<number[][]>([]);
  const [isRecording, setRecording] = useState(false);
  const [gpsAccuracy, setAccuracy]  = useState<number | null>(null);
  const [center, setCenter]         = useState<[number, number]>([-44.42, -2.40]);
  const watchId                     = useRef<number | null>(null);

  const stopWatch = useCallback(() => {
    if (watchId.current !== null) {
      Geolocation.clearWatch(watchId.current);
      watchId.current = null;
    }
    setRecording(false);
  }, []);

  const startWatch = useCallback(() => {
    setRecording(true);
    watchId.current = Geolocation.watchPosition(
      (pos) => {
        const { longitude, latitude, accuracy } = pos.coords;
        setAccuracy(Math.round(accuracy));
        setCenter([longitude, latitude]);
        if (accuracy <= 12) {
          setCoords(prev => [...prev, [longitude, latitude]]);
        }
      },
      (err) => console.warn('GPS erro:', err.message),
      { enableHighAccuracy: true, distanceFilter: 3, interval: 2000 }
    );
  }, []);

  useEffect(() => {
    if (mode === 'gps_walk') startWatch();
    return stopWatch;
  }, [mode]);

  const toggleMode = () => {
    stopWatch();
    setMode(m => m === 'gps_walk' ? 'manual_draw' : 'gps_walk');
  };

  const handleMapPress = (e: any) => {
    if (mode !== 'manual_draw') return;
    const [lng, lat] = e.geometry.coordinates;
    setCoords(prev => [...prev, [lng, lat]]);
    if (coords.length === 0) setCenter([lng, lat]);
  };

  const undoLast = () => setCoords(prev => prev.slice(0, -1));

  const finalize = () => {
    stopWatch();
    if (coords.length < 3) {
      Alert.alert('Área inválida', 'São necessários pelo menos 3 pontos para formar um polígono.');
      return;
    }
    const simplified = rdpSimplify(coords, 0.00003);
    const closed     = closePolygon(simplified);
    const polygon    = { type: 'Polygon', coordinates: [closed] };
    navigation.navigate('NovaSessao', { polygon, polygon_source: mode });
  };

  const pathGeoJSON = { type: 'Feature', geometry: { type: 'LineString', coordinates: coords } };
  const polygonPreview = coords.length >= 3 ? {
    type: 'Feature', geometry: { type: 'Polygon', coordinates: [closePolygon(coords)] },
  } : null;

  return (
    <View style={{ flex: 1 }}>
      <OfflineBanner />
      <MapboxMap center={center} zoom={16} onPress={handleMapPress}>
        <Mapbox.ShapeSource id="path" shape={pathGeoJSON as any}>
          <Mapbox.LineLayer id="pathLine"
            style={{ lineColor: colors.terracotta, lineWidth: 3, lineOpacity: 0.9 }}
          />
        </Mapbox.ShapeSource>

        {polygonPreview && (
          <Mapbox.ShapeSource id="preview" shape={polygonPreview as any}>
            <Mapbox.FillLayer id="previewFill"
              style={{ fillColor: colors.terracotta, fillOpacity: 0.2 }}
            />
          </Mapbox.ShapeSource>
        )}

        <View style={s.statusBadge}>
          <Text style={s.statusText}>
            {isRecording ? '🟢 Gravando' : '⏸ Pausado'}
            {gpsAccuracy ? ` · ±${gpsAccuracy}m` : ''}
            {` · ${coords.length} pts`}
          </Text>
        </View>

        <TouchableOpacity style={s.modeBtn} onPress={toggleMode}>
          <Text style={s.modeBtnText}>
            {mode === 'gps_walk' ? '✏️ Modo Manual' : '🚶 GPS Auto'}
          </Text>
        </TouchableOpacity>
      </MapboxMap>

      <View style={s.bottomBar}>
        <TouchableOpacity style={s.undoBtn} onPress={undoLast}>
          <Text style={s.undoBtnText}>↩ Desfazer</Text>
        </TouchableOpacity>
        <TouchableOpacity style={s.finalBtn} onPress={finalize}>
          <Text style={s.finalBtnText}>✓ Finalizar Polígono</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  statusBadge:  { position: 'absolute', top: 12, left: 12, zIndex: 10, backgroundColor: 'rgba(52,34,25,0.88)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5 },
  statusText:   { color: '#FFF7E8', fontWeight: '700', fontSize: 12 },
  modeBtn:      { position: 'absolute', top: 12, right: 12, zIndex: 10, backgroundColor: 'rgba(52,34,25,0.88)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 6 },
  modeBtnText:  { color: '#FFF7E8', fontWeight: '700', fontSize: 12 },
  bottomBar:    { backgroundColor: colors.cream, flexDirection: 'row', padding: 12, gap: 10, borderTopWidth: 1, borderTopColor: 'rgba(209,209,167,0.5)' },
  undoBtn:      { flex: 1, borderWidth: 1.5, borderColor: 'rgba(73,78,58,0.4)', borderRadius: 9, paddingVertical: 11, alignItems: 'center' },
  undoBtnText:  { color: colors.brown, fontWeight: '700', fontSize: 13 },
  finalBtn:     { flex: 2, backgroundColor: colors.terracotta, borderRadius: 9, paddingVertical: 11, alignItems: 'center' },
  finalBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
});
