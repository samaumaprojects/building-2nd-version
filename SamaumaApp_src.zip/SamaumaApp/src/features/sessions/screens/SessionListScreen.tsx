import React from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, RefreshControl,
} from 'react-native';
import { useSessions } from '../hooks/useSessions';
import OfflineBanner from '../../../components/OfflineBanner';
import { colors } from '../../../constants/colors';
import { theme } from '../../../constants/theme';
import type { ApiPlantingSession } from '../../../services/api';
import { useAuthStore } from '../../auth/authStore';

const TYPE_LABELS: Record<string, string> = {
  planting:   'Plantio',
  replanting: 'Replantio',
};

export default function SessionListScreen({ route, navigation }: any) {
  const { projectId } = route.params;
  const { data: sessions, isLoading, refetch, isRefetching } = useSessions(projectId);
  const user = useAuthStore(s => s.user);

  return (
    <View style={theme.screen}>
      <OfflineBanner />
      {isLoading ? (
        <View style={s.center}><ActivityIndicator color={colors.terracotta} size="large" /></View>
      ) : (
        <FlatList
          data={sessions ?? []}
          keyExtractor={(item: ApiPlantingSession) => String(item.id)}
          contentContainerStyle={theme.scrollContent}
          refreshControl={
            <RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={colors.terracotta} />
          }
          renderItem={({ item: session }) => (
            <TouchableOpacity
              style={s.card}
              onPress={() => navigation.navigate('ListaMonitoramento', {
                sessionId: String(session.id),
                sessionName: session.name,
              })}
              activeOpacity={0.85}
            >
              <View style={s.cardHeader}>
                <View style={s.typeBadge}>
                  <Text style={s.typeBadgeText}>{TYPE_LABELS[session.type] ?? session.type}</Text>
                </View>
                {session.polygon ? (
                  <View style={s.polygonBadge}>
                    <Text style={s.polygonBadgeText}>Polígono registrado</Text>
                  </View>
                ) : (
                  <View style={[s.polygonBadge, s.polygonMissing]}>
                    <Text style={[s.polygonBadgeText, { color: colors.terracotta }]}>Sem polígono</Text>
                  </View>
                )}
              </View>
              <Text style={s.sessionName}>{session.name}</Text>
              <View style={s.statsRow}>
                {session.area_ha != null && (
                  <View style={s.tag}>
                    <Text style={s.tagText}>{session.area_ha} ha</Text>
                  </View>
                )}
                {session.total_seedlings != null && (
                  <View style={s.tag}>
                    <Text style={s.tagText}>
                      {session.total_seedlings.toLocaleString('pt-BR')} mudas
                    </Text>
                  </View>
                )}
                {session.methodology && (
                  <View style={s.tag}>
                    <Text style={s.tagText}>{session.methodology}</Text>
                  </View>
                )}
              </View>
              <Text style={s.date}>
                {new Date(session.started_at).toLocaleDateString('pt-BR')}
              </Text>
            </TouchableOpacity>
          )}
          ListEmptyComponent={
            <View style={s.center}>
              <Text style={s.empty}>Nenhuma sessão de plantio registrada.</Text>
              <Text style={s.emptySub}>Toque + para adicionar a primeira sessão.</Text>
            </View>
          }
        />
      )}

      {user?.role === 'admin' && (
        <TouchableOpacity
          style={s.fab}
          onPress={() => navigation.navigate('NovaSessao', { projectId })}
          activeOpacity={0.85}
        >
          <Text style={s.fabText}>+</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  center:           { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  card:             { backgroundColor: colors.white, borderRadius: 12, padding: 14, marginBottom: 9, borderLeftWidth: 3, borderLeftColor: colors.terracotta, shadowColor: colors.brown, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 2 },
  cardHeader:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  typeBadge:        { backgroundColor: colors.terracotta + '22', borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  typeBadgeText:    { fontSize: 9, fontWeight: '700', color: colors.terracotta },
  sessionName:      { fontSize: 14, fontWeight: '700', color: colors.brown, marginBottom: 8 },
  statsRow:         { flexDirection: 'row', gap: 5, flexWrap: 'wrap', marginBottom: 4 },
  tag:              { backgroundColor: colors.sage, borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  tagText:          { fontSize: 10, fontWeight: '700', color: colors.green },
  date:             { fontSize: 10, color: '#888', marginTop: 2 },
  polygonBadge:     { backgroundColor: 'rgba(45,122,64,0.12)', borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  polygonMissing:   { backgroundColor: 'rgba(196,135,93,0.12)' },
  polygonBadgeText: { fontSize: 9, fontWeight: '700', color: colors.green },
  empty:            { fontSize: 14, color: '#aaa', fontWeight: '700', marginBottom: 6 },
  emptySub:         { fontSize: 11, color: '#bbb' },
  fab:              { position: 'absolute', bottom: 24, right: 20, width: 52, height: 52, borderRadius: 26, backgroundColor: colors.terracotta, alignItems: 'center', justifyContent: 'center', shadowColor: colors.terracotta, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.45, shadowRadius: 10, elevation: 6 },
  fabText:          { color: '#fff', fontSize: 26, lineHeight: 30, fontWeight: '300' },
});
