function perpendicularDist(p: number[], a: number[], b: number[]): number {
  const [x0, y0] = p, [x1, y1] = a, [x2, y2] = b;
  const num = Math.abs((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1);
  const den = Math.sqrt((y2 - y1) ** 2 + (x2 - x1) ** 2);
  return den === 0 ? 0 : num / den;
}

/** Ramer-Douglas-Peucker: simplifica o polígono mantendo a forma */
export function rdpSimplify(points: number[][], epsilon = 0.00003): number[][] {
  if (points.length <= 2) return points;
  let maxDist = 0, maxIdx = 0;
  const start = points[0], end = points[points.length - 1];
  for (let i = 1; i < points.length - 1; i++) {
    const d = perpendicularDist(points[i], start, end);
    if (d > maxDist) { maxDist = d; maxIdx = i; }
  }
  if (maxDist > epsilon) {
    const left  = rdpSimplify(points.slice(0, maxIdx + 1), epsilon);
    const right = rdpSimplify(points.slice(maxIdx), epsilon);
    return [...left.slice(0, -1), ...right];
  }
  return [start, end];
}

export function closePolygon(coords: number[][]): number[][] {
  if (coords.length < 2) return coords;
  return [...coords, coords[0]];
}
