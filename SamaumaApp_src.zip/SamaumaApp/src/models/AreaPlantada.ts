import { Model } from '@nozbe/watermelondb';
import { field, text, readonly, relation } from '@nozbe/watermelondb/decorators';

export default class AreaPlantada extends Model {
  static table = 'areas_plantadas';
  static associations = {
    projetos: { type: 'belongs_to', key: 'projeto_id' },
  } as const;

  @text('remote_id')             remoteId!: string;
  @text('projeto_id')            projetoId!: string;
  @text('nome_area')             nomeArea!: string;
  @field('total_area_hectares')  totalAreaHectares!: number | null;
  @field('num_arvores_na_area')  numArvores!: number | null;
  @text('outras_informacoes')    outrasInformacoes!: string | null;
  @text('polygon_json')          polygonJson!: string | null;
  @field('synced')               synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @relation('projetos', 'projeto_id') projeto!: any;

  /** Retorna o polígono GeoJSON para uso no Mapbox */
  get polygon(): object | null {
    try { return this.polygonJson ? JSON.parse(this.polygonJson) : null; }
    catch { return null; }
  }
}
