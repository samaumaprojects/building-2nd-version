import { Model } from '@nozbe/watermelondb';
import { field, text, readonly, relation } from '@nozbe/watermelondb/decorators';

export default class Evolucao extends Model {
  static table = 'evolucoes';
  static associations = {
    projetos: { type: 'belongs_to', key: 'projeto_id' },
  } as const;

  @text('remote_id')              remoteId!: string;
  @text('projeto_id')             projetoId!: string;
  @text('data_registro')          dataRegistro!: string;
  @text('descricao')              descricao!: string;
  @text('indicador_crescimento')  indicadorCrescimento!: string | null;
  @text('observacoes')            observacoes!: string | null;
  @field('synced')                synced!: boolean;
  @readonly @field('updated_at')  updatedAt!: number;

  @relation('projetos', 'projeto_id') projeto!: any;
}
