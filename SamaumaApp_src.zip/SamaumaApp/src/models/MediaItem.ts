import { Model } from '@nozbe/watermelondb';
import { field, text, readonly } from '@nozbe/watermelondb/decorators';

// owner_type: 'planting_session' | 'sample_point' | 'project'
// type: 'photo' | 'video'
// role: 'fotoponto' | 'borda' | 'session_photo' | 'session_video'
export default class MediaItem extends Model {
  static table = 'media_items';

  @text('remote_id')   remoteId!: string | null;
  @text('owner_type')  ownerType!: string;
  @text('owner_id')    ownerId!: string;
  @text('type')        mediaType!: string;
  @text('role')        role!: string;
  @text('local_uri')   localUri!: string;
  @text('remote_url')  remoteUrl!: string | null;
  @field('latitude')   latitude!: number | null;
  @field('longitude')  longitude!: number | null;
  @field('accuracy')   accuracy!: number | null;
  @field('taken_at')   takenAt!: number;
  @field('duration_ms') durationMs!: number | null;
  @field('synced')     synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;
}
