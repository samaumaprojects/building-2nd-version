import { Model } from '@nozbe/watermelondb';
import { field, text, relation, readonly } from '@nozbe/watermelondb/decorators';

export default class MonitoringForm extends Model {
  static table = 'monitoring_forms';
  static associations = {
    monitoring_tasks: { type: 'belongs_to', key: 'task_id' },
    sample_points:    { type: 'belongs_to', key: 'sample_point_id' },
  } as const;

  @text('remote_id')               remoteId!: string;
  @text('task_id')                 taskId!: string;
  @text('sample_point_id')         samplePointId!: string;
  @text('observer_name')           observerName!: string;
  @field('observed_at')            observedAt!: number;
  @text('species')                 species!: string;
  @field('alive_count')            aliveCount!: number;
  @field('dead_count')             deadCount!: number;
  @field('dormant_count')          dormantCount!: number;
  @field('natural_recovery_count') naturalRecoveryCount!: number | null;
  @text('natural_recovery_species') naturalRecoverySpecies!: string | null;
  @field('salinity')               salinity!: number | null;
  @field('crab_burrows')           crabBurrows!: number | null;
  @field('height_cm')              heightCm!: number | null;
  @field('stem_diameter_mm')       stemDiameterMm!: number | null;
  @field('leaf_count')             leafCount!: number | null;
  @text('notes')                   notes!: string | null;
  @text('form_status')             formStatus!: 'draft' | 'completed';
  @field('synced')                 synced!: boolean;
  @readonly @field('updated_at')   updatedAt!: number;

  @relation('monitoring_tasks', 'task_id')           task!: any;
  @relation('sample_points',    'sample_point_id')   samplePoint!: any;
}
