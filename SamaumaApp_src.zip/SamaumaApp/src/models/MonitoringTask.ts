import { Model } from '@nozbe/watermelondb';
import { field, text, relation, children, readonly } from '@nozbe/watermelondb/decorators';

export type TaskStage = '3_months' | '6_months' | '1_year' | '2_years' | '3_years';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'overdue';

export const STAGE_LABELS: Record<TaskStage, string> = {
  '3_months': '3 Meses',
  '6_months': '6 Meses',
  '1_year':   '1 Ano',
  '2_years':  '2 Anos',
  '3_years':  '3 Anos',
};

export default class MonitoringTask extends Model {
  static table = 'monitoring_tasks';
  static associations = {
    planting_sessions: { type: 'belongs_to', key: 'session_id' },
    monitoring_forms:  { type: 'has_many',   foreignKey: 'task_id' },
  } as const;

  @text('remote_id')  remoteId!: string | null;
  @text('session_id') sessionId!: string;
  @text('stage')      stage!: TaskStage;
  @field('due_date')  dueDate!: number;
  @text('status')     status!: TaskStatus;
  @field('synced')    synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @relation('planting_sessions', 'session_id') session!: any;
  @children('monitoring_forms') forms!: any;

  get stageLabel(): string { return STAGE_LABELS[this.stage] ?? this.stage; }
  get showGrowthFields(): boolean { return this.stage !== '3_months'; }
  get dueDateFormatted(): string {
    return new Date(this.dueDate).toLocaleDateString('pt-BR');
  }
}
