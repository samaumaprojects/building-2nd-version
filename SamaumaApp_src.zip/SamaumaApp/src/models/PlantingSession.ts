import { Model } from '@nozbe/watermelondb';
import { field, text, relation, children, readonly } from '@nozbe/watermelondb/decorators';

export default class PlantingSession extends Model {
  static table = 'planting_sessions';
  static associations = {
    projects:         { type: 'belongs_to', key: 'project_id' },
    sponsors:         { type: 'belongs_to', key: 'sponsor_id' },
    sample_points:    { type: 'has_many',   foreignKey: 'session_id' },
    monitoring_tasks: { type: 'has_many',   foreignKey: 'session_id' },
  } as const;

  @text('remote_id')            remoteId!: string | null;
  @text('project_id')           projectId!: string;
  @text('sponsor_id')           sponsorId!: string | null;
  @text('name')                 name!: string;
  @text('type')                 type!: 'planting' | 'replanting';
  @text('methodology')          methodology!: string | null;
  @text('conditions')           conditions!: string | null;
  @text('assessor_id')          assessorId!: string | null;
  @field('started_at')          startedAt!: number;
  @text('species_counts_json')  speciesCountsJson!: string | null;
  @field('total_seedlings')     totalSeedlings!: number | null;
  @field('area_ha')             areaHa!: number | null;
  @field('spacing_m')           spacingM!: number | null;
  @field('plantable_pct')       plantablePct!: number | null;
  @text('polygon_json')         polygonJson!: string | null;
  @text('polygon_source')       polygonSource!: 'gps_walk' | 'manual_draw' | null;
  @field('synced')              synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @relation('projects', 'project_id') project!: any;
  @relation('sponsors', 'sponsor_id') sponsor!: any;
  @children('sample_points')    samplePoints!: any;
  @children('monitoring_tasks') monitoringTasks!: any;

  get speciesCounts(): Array<{ species: string; count: number }> {
    try { return JSON.parse(this.speciesCountsJson ?? '[]') ?? []; }
    catch { return []; }
  }
  get polygon(): object | null {
    try { return this.polygonJson ? JSON.parse(this.polygonJson) : null; }
    catch { return null; }
  }
}
