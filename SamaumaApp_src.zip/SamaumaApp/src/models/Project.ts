import { Model } from '@nozbe/watermelondb';
import { field, text, readonly, children } from '@nozbe/watermelondb/decorators';

export default class Project extends Model {
  static table = 'projects';
  static associations = {
    sponsors:          { type: 'has_many', foreignKey: 'project_id' },
    planting_sessions: { type: 'has_many', foreignKey: 'project_id' },
  } as const;

  @text('remote_id')           remoteId!: string | null;
  @text('name')                name!: string;
  @text('description')         description!: string | null;
  @text('state')               state!: string | null;
  @text('municipality')        municipality!: string | null;
  @text('start_date')          startDate!: string;
  @text('end_date')            endDate!: string | null;
  @text('field_leader_id')     fieldLeaderId!: string | null;
  @text('species_json')        speciesJson!: string | null;
  @text('methodologies_json')  methodologiesJson!: string | null;
  @text('conditions_json')     conditionsJson!: string | null;
  @text('polygon_json')        polygonJson!: string | null;
  @text('status')              status!: 'active' | 'paused' | 'completed';
  @field('synced')             synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @children('sponsors')          sponsors!: any;
  @children('planting_sessions') sessions!: any;

  get species(): string[] {
    try { return JSON.parse(this.speciesJson ?? '[]') ?? []; }
    catch { return []; }
  }
  get methodologies(): string[] {
    try { return JSON.parse(this.methodologiesJson ?? '[]') ?? []; }
    catch { return []; }
  }
  get conditions(): string[] {
    try { return JSON.parse(this.conditionsJson ?? '[]') ?? []; }
    catch { return []; }
  }
  get polygon(): object | null {
    try { return this.polygonJson ? JSON.parse(this.polygonJson) : null; }
    catch { return null; }
  }
}
