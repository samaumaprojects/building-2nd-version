import { Model } from '@nozbe/watermelondb';
import { field, text, readonly, children } from '@nozbe/watermelondb/decorators';

export default class Projeto extends Model {
  static table = 'projetos';
  static associations = {
    areas_plantadas: { type: 'has_many', foreignKey: 'projeto_id' },
    evolucoes:       { type: 'has_many', foreignKey: 'projeto_id' },
  } as const;

  @text('remote_id')          remoteId!: string;
  @text('nome')               nome!: string;
  @text('descricao')          descricao!: string;
  @text('data_inicio')        dataInicio!: string;
  @text('data_fim_estimada')  dataFimEstimada!: string | null;
  @field('orcamento')         orcamento!: number | null;
  @text('status')             status!: string;
  @field('synced')            synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @children('areas_plantadas') areas!: any;
  @children('evolucoes')       evolucoes!: any;
}
