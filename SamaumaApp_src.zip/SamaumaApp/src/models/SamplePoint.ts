import { Model } from '@nozbe/watermelondb';
import { field, text, relation, readonly } from '@nozbe/watermelondb/decorators';

export default class SamplePoint extends Model {
  static table = 'sample_points';
  static associations = {
    planting_sessions: { type: 'belongs_to', key: 'session_id' },
  } as const;

  @text('remote_id')  remoteId!: string | null;
  @text('session_id') sessionId!: string;
  @text('label')      label!: string;
  @field('latitude')  latitude!: number;
  @field('longitude') longitude!: number;
  @text('source')     source!: 'kml_import' | 'manual_creation' | null;
  @field('synced')    synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @relation('planting_sessions', 'session_id') session!: any;
}
