import { Model } from '@nozbe/watermelondb';
import { field, text, relation, readonly } from '@nozbe/watermelondb/decorators';

export default class Sponsor extends Model {
  static table = 'sponsors';
  static associations = {
    projects: { type: 'belongs_to', key: 'project_id' },
  } as const;

  @text('remote_id')     remoteId!: string | null;
  @text('project_id')    projectId!: string;
  @text('name')          name!: string;
  @text('contract_ref')  contractRef!: string | null;
  @text('type')          type!: string | null;
  @text('status')        status!: 'active' | 'potential';
  @field('target_trees') targetTrees!: number | null;
  @field('planted_trees') plantedTrees!: number;
  @field('synced')       synced!: boolean;
  @readonly @field('updated_at') updatedAt!: number;

  @relation('projects', 'project_id') project!: any;

  get progressPct(): number | null {
    if (!this.targetTrees || this.targetTrees === 0) return null;
    return Math.min(100, (this.plantedTrees / this.targetTrees) * 100);
  }
  get remaining(): number {
    if (!this.targetTrees) return 0;
    return Math.max(0, this.targetTrees - this.plantedTrees);
  }
}
