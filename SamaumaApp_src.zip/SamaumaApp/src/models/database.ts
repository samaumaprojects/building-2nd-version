import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import schema from './schema';
import Project from './Project';
import Sponsor from './Sponsor';
import PlantingSession from './PlantingSession';
import SamplePoint from './SamplePoint';
import MonitoringTask from './MonitoringTask';
import MonitoringForm from './MonitoringForm';
import MediaItem from './MediaItem';

const adapter = new SQLiteAdapter({
  schema,
  dbName: 'samauma_v4',
  jsi: true,
  onSetUpError: (err) => {
    console.error('WatermelonDB setup error:', err);
  },
});

export const database = new Database({
  adapter,
  modelClasses: [
    Project,
    Sponsor,
    PlantingSession,
    SamplePoint,
    MonitoringTask,
    MonitoringForm,
    MediaItem,
  ],
});

export const collections = {
  projects:  () => database.get<Project>('projects'),
  sponsors:  () => database.get<Sponsor>('sponsors'),
  sessions:  () => database.get<PlantingSession>('planting_sessions'),
  points:    () => database.get<SamplePoint>('sample_points'),
  tasks:     () => database.get<MonitoringTask>('monitoring_tasks'),
  forms:     () => database.get<MonitoringForm>('monitoring_forms'),
  media:     () => database.get<MediaItem>('media_items'),
};
