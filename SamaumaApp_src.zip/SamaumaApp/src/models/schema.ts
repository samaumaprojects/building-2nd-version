import { appSchema, tableSchema } from '@nozbe/watermelondb';

export default appSchema({
  version: 4,
  tables: [
    tableSchema({
      name: 'projects',
      columns: [
        { name: 'remote_id',      type: 'string',  isOptional: true },
        { name: 'name',           type: 'string' },
        { name: 'description',    type: 'string',  isOptional: true },
        { name: 'state',          type: 'string',  isOptional: true },
        { name: 'municipality',   type: 'string',  isOptional: true },
        { name: 'start_date',     type: 'string' },
        { name: 'end_date',       type: 'string',  isOptional: true },
        { name: 'field_leader_id',type: 'string',  isOptional: true },
        { name: 'species_json',   type: 'string',  isOptional: true },   // JSON string[]
        { name: 'methodologies_json', type: 'string', isOptional: true }, // JSON string[]
        { name: 'conditions_json', type: 'string', isOptional: true },    // JSON string[]
        { name: 'polygon_json',   type: 'string',  isOptional: true },    // GeoJSON Feature
        { name: 'status',         type: 'string' },                       // active|paused|completed
        { name: 'synced',         type: 'boolean' },
        { name: 'updated_at',     type: 'number' },
      ],
    }),
    tableSchema({
      name: 'sponsors',
      columns: [
        { name: 'remote_id',      type: 'string',  isOptional: true },
        { name: 'project_id',     type: 'string',  isIndexed: true },
        { name: 'name',           type: 'string' },
        { name: 'contract_ref',   type: 'string',  isOptional: true },
        { name: 'type',           type: 'string',  isOptional: true },
        { name: 'status',         type: 'string' },                       // active|potential
        { name: 'target_trees',   type: 'number',  isOptional: true },
        { name: 'planted_trees',  type: 'number',  isOptional: true },
        { name: 'synced',         type: 'boolean' },
        { name: 'updated_at',     type: 'number' },
      ],
    }),
    tableSchema({
      name: 'planting_sessions',
      columns: [
        { name: 'remote_id',        type: 'string',  isOptional: true },
        { name: 'project_id',       type: 'string',  isIndexed: true },
        { name: 'sponsor_id',       type: 'string',  isOptional: true },
        { name: 'name',             type: 'string' },
        { name: 'type',             type: 'string' },                     // planting|replanting
        { name: 'methodology',      type: 'string',  isOptional: true },
        { name: 'conditions',       type: 'string',  isOptional: true },
        { name: 'assessor_id',      type: 'string',  isOptional: true },
        { name: 'started_at',       type: 'number' },
        { name: 'species_counts_json', type: 'string', isOptional: true },// JSON [{species,count}]
        { name: 'total_seedlings',  type: 'number',  isOptional: true },
        { name: 'area_ha',          type: 'number',  isOptional: true },
        { name: 'spacing_m',        type: 'number',  isOptional: true },
        { name: 'plantable_pct',    type: 'number',  isOptional: true },
        { name: 'polygon_json',     type: 'string',  isOptional: true },  // GeoJSON
        { name: 'polygon_source',   type: 'string',  isOptional: true },  // gps_walk|manual_draw
        { name: 'synced',           type: 'boolean' },
        { name: 'updated_at',       type: 'number' },
      ],
    }),
    tableSchema({
      name: 'sample_points',
      columns: [
        { name: 'remote_id',    type: 'string',  isOptional: true },
        { name: 'session_id',   type: 'string',  isIndexed: true },
        { name: 'label',        type: 'string' },
        { name: 'latitude',     type: 'number' },
        { name: 'longitude',    type: 'number' },
        { name: 'source',       type: 'string',  isOptional: true },  // kml_import|manual_creation
        { name: 'synced',       type: 'boolean' },
        { name: 'updated_at',   type: 'number' },
      ],
    }),
    tableSchema({
      name: 'monitoring_tasks',
      columns: [
        { name: 'remote_id',    type: 'string',  isOptional: true },
        { name: 'session_id',   type: 'string',  isIndexed: true },
        { name: 'stage',        type: 'string' }, // 3_months|6_months|1_year|2_years|3_years
        { name: 'due_date',     type: 'number' },
        { name: 'status',       type: 'string' }, // pending|in_progress|completed|overdue
        { name: 'synced',       type: 'boolean' },
        { name: 'updated_at',   type: 'number' },
      ],
    }),
    tableSchema({
      name: 'monitoring_forms',
      columns: [
        { name: 'remote_id',                type: 'string',  isOptional: true },
        { name: 'task_id',                  type: 'string',  isIndexed: true },
        { name: 'sample_point_id',          type: 'string' },
        { name: 'observer_name',            type: 'string' },
        { name: 'observed_at',              type: 'number' },
        { name: 'species',                  type: 'string' },
        { name: 'alive_count',              type: 'number' },
        { name: 'dead_count',               type: 'number' },
        { name: 'dormant_count',            type: 'number' },
        { name: 'natural_recovery_count',   type: 'number',  isOptional: true },
        { name: 'natural_recovery_species', type: 'string',  isOptional: true },
        { name: 'salinity',                 type: 'number',  isOptional: true },
        { name: 'crab_burrows',             type: 'number',  isOptional: true },
        { name: 'height_cm',               type: 'number',  isOptional: true },
        { name: 'stem_diameter_mm',        type: 'number',  isOptional: true },
        { name: 'leaf_count',              type: 'number',  isOptional: true },
        { name: 'notes',                   type: 'string',  isOptional: true },
        { name: 'form_status',             type: 'string' }, // draft|completed
        { name: 'synced',                  type: 'boolean' },
        { name: 'updated_at',             type: 'number' },
      ],
    }),
    tableSchema({
      name: 'media_items',
      columns: [
        { name: 'remote_id',    type: 'string',  isOptional: true },
        { name: 'owner_type',   type: 'string' },
        { name: 'owner_id',     type: 'string',  isIndexed: true },
        { name: 'type',         type: 'string' },  // photo|video
        { name: 'role',         type: 'string' },  // fotoponto|borda|session_photo|session_video
        { name: 'local_uri',    type: 'string' },
        { name: 'remote_url',   type: 'string',  isOptional: true },
        { name: 'latitude',     type: 'number',  isOptional: true },
        { name: 'longitude',    type: 'number',  isOptional: true },
        { name: 'accuracy',     type: 'number',  isOptional: true },
        { name: 'taken_at',     type: 'number' },
        { name: 'duration_ms',  type: 'number',  isOptional: true },
        { name: 'synced',       type: 'boolean' },
        { name: 'updated_at',   type: 'number' },
      ],
    }),
  ],
});
