import React, { createRef } from 'react';
import { NavigationContainer, NavigationContainerRef } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

import { useAuthStore } from '../features/auth/authStore';
import { colors } from '../constants/colors';

// Auth
import LoginScreen           from '../features/auth/LoginScreen';

// Projects
import ProjectListScreen     from '../features/projects/screens/ProjectListScreen';
import ProjectDetailScreen   from '../features/projects/screens/ProjectDetailScreen';
import FullMapScreen         from '../features/projects/screens/FullMapScreen';
import CriarProjetoScreen    from '../features/projects/screens/CriarProjetoScreen';
import EditarProjetoScreen   from '../features/projects/screens/EditarProjetoScreen';

// Sessions
import SessionListScreen     from '../features/sessions/screens/SessionListScreen';
import NewSessionScreen      from '../features/sessions/screens/NewSessionScreen';
import RecordPathScreen      from '../features/sessions/screens/RecordPathScreen';

// Monitoring
import MonitoringListScreen  from '../features/monitoring/screens/MonitoringListScreen';
import TaskDetailScreen      from '../features/monitoring/screens/TaskDetailScreen';
import MonitoringFormScreen  from '../features/monitoring/screens/MonitoringFormScreen';

// navigationRef: allows navigation from notificationService (outside React tree)
export const navigationRef = createRef<NavigationContainerRef<any>>();

const Stack  = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

const headerOptions = {
  headerStyle:        { backgroundColor: colors.brown },
  headerTintColor:    colors.cream,
  headerTitleStyle:   { fontWeight: '700' as const, fontSize: 16 },
  contentStyle:       { backgroundColor: colors.cream },
  headerShadowVisible: false,
  headerBottomContainerStyle: { borderBottomWidth: 1.5, borderBottomColor: colors.terracotta },
};

// ─── Auth Stack ───────────────────────────────────────────────────────────────
function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
    </Stack.Navigator>
  );
}

// ─── Admin main stack (all screens) ──────────────────────────────────────────
function AdminStack() {
  return (
    <Stack.Navigator screenOptions={headerOptions}>
      <Stack.Screen name="ProjetosList"     component={ProjectListScreen}    options={{ title: 'Projetos Samaúma' }} />
      <Stack.Screen name="DetalhesProjeto"  component={ProjectDetailScreen}  options={{ title: 'Detalhes do Projeto' }} />
      <Stack.Screen name="CriarProjeto"     component={CriarProjetoScreen}   options={{ title: 'Novo Projeto' }} />
      <Stack.Screen name="EditarProjeto"    component={EditarProjetoScreen}  options={{ title: 'Editar Projeto' }} />
      <Stack.Screen name="MapaCompleto"     component={FullMapScreen}         options={{ title: 'Mapa', headerTransparent: true, headerTintColor: colors.cream }} />
      <Stack.Screen name="SessoesProjeto"   component={SessionListScreen}    options={{ title: 'Sessões de Plantio' }} />
      <Stack.Screen name="NovaSessao"       component={NewSessionScreen}     options={{ title: 'Nova Sessão' }} />
      <Stack.Screen name="RegistrarCaminho" component={RecordPathScreen}     options={{ title: 'Registrar Área', headerTransparent: true, headerTintColor: colors.cream }} />
      <Stack.Screen name="ListaMonitoramento" component={MonitoringListScreen} options={{ title: 'Monitoramento' }} />
      <Stack.Screen name="Tarefa"           component={TaskDetailScreen}     options={{ title: 'Tarefa de Monitoramento' }} />
      <Stack.Screen name="Formulario"       component={MonitoringFormScreen} options={{ title: 'Formulário de Campo' }} />
    </Stack.Navigator>
  );
}

// ─── Admin Drawer ─────────────────────────────────────────────────────────────
function AdminDrawer() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle:      { backgroundColor: colors.brown },
        headerTintColor:  colors.cream,
        headerTitleStyle: { fontWeight: '700' as const, fontSize: 16 },
        drawerStyle:      { backgroundColor: colors.cream },
        drawerActiveTintColor:   colors.terracotta,
        drawerInactiveTintColor: colors.brown,
        drawerLabelStyle:  { fontWeight: '700', fontSize: 13 },
        headerShown: false, // AdminStack handles its own header
      }}
    >
      <Drawer.Screen
        name="AdminStack"
        component={AdminStack}
        options={{ title: 'Projetos', drawerLabel: 'Projetos' }}
      />
      <Drawer.Screen
        name="MapaGeral"
        component={FullMapScreen}
        options={{ title: 'Mapa Geral', drawerLabel: 'Mapa Geral', headerShown: true }}
      />
    </Drawer.Navigator>
  );
}

// ─── Field Leader Stack ───────────────────────────────────────────────────────
function FieldLeaderStack() {
  return (
    <Stack.Navigator screenOptions={headerOptions}>
      <Stack.Screen name="ProjetosList"     component={ProjectListScreen}    options={{ title: 'Meu Projeto' }} />
      <Stack.Screen name="DetalhesProjeto"  component={ProjectDetailScreen}  options={{ title: 'Detalhes' }} />
      <Stack.Screen name="MapaCompleto"     component={FullMapScreen}         options={{ title: 'Mapa', headerTransparent: true }} />
      <Stack.Screen name="SessoesProjeto"   component={SessionListScreen}    options={{ title: 'Sessões' }} />
      <Stack.Screen name="NovaSessao"       component={NewSessionScreen}     options={{ title: 'Nova Sessão' }} />
      <Stack.Screen name="RegistrarCaminho" component={RecordPathScreen}     options={{ title: 'Registrar Área', headerTransparent: true }} />
      <Stack.Screen name="ListaMonitoramento" component={MonitoringListScreen} options={{ title: 'Monitoramento' }} />
      <Stack.Screen name="Tarefa"           component={TaskDetailScreen}     options={{ title: 'Minha Tarefa' }} />
      <Stack.Screen name="Formulario"       component={MonitoringFormScreen} options={{ title: 'Formulário de Campo' }} />
    </Stack.Navigator>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────
export default function RootNavigator() {
  const { token, user } = useAuthStore();

  return (
    <NavigationContainer ref={navigationRef}>
      {!token ? (
        <AuthStack />
      ) : user?.role === 'admin' ? (
        <AdminDrawer />
      ) : (
        <FieldLeaderStack />
      )}
    </NavigationContainer>
  );
}
