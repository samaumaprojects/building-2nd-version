import axios, { AxiosError } from 'axios';
import { useAuthStore } from '../features/auth/authStore';
import { API_URL } from '../config';

export const API_BASE_URL = API_URL;

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

// Inject Bearer token in all requests
api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error),
);

// Auto-logout on 401
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    if (error.response?.status === 401) useAuthStore.getState().logout();
    return Promise.reject(error);
  },
);

export default api;

// ─── API Response Types ───────────────────────────────────────────────────────

export interface ApiProject {
  id:                 string;
  remote_id?:         string;
  name:               string;
  description?:       string;
  state?:             string;
  municipality?:      string;
  start_date:         string;
  end_date?:          string;
  field_leader_id?:   string;
  species?:           string[];
  methodologies?:     string[];
  conditions?:        string[];
  polygon?:           object | null;
  status:             'active' | 'paused' | 'completed';
  sponsors?:          ApiSponsor[];
  sessions?:          ApiPlantingSession[];
  updated_at?:        string;
}

export interface ApiSponsor {
  id:            string;
  project_id:    string;
  name:          string;
  contract_ref?: string;
  type?:         string;
  status:        'active' | 'potential';
  target_trees?: number;
  planted_trees?: number;
  updated_at?:   string;
}

export interface ApiPlantingSession {
  id:                string;
  project_id:        string;
  sponsor_id?:       string;
  name:              string;
  type:              'planting' | 'replanting';
  methodology?:      string;
  conditions?:       string;
  assessor_id?:      string;
  started_at:        number;
  species_counts?:   Array<{ species: string; count: number }>;
  total_seedlings?:  number;
  area_ha?:          number;
  spacing_m?:        number;
  plantable_pct?:    number;
  polygon?:          object | null;
  polygon_source?:   'gps_walk' | 'manual_draw';
  updated_at?:       string;
}

export interface ApiSamplePoint {
  id:         string;
  session_id: string;
  label:      string;
  latitude:   number;
  longitude:  number;
  source?:    'kml_import' | 'manual_creation';
}

export interface ApiMonitoringTask {
  id:         string;
  session_id: string;
  stage:      '3_months' | '6_months' | '1_year' | '2_years' | '3_years';
  due_date:   number;
  status:     'pending' | 'in_progress' | 'completed' | 'overdue';
  session?:   ApiPlantingSession;
  forms?:     ApiMonitoringForm[];
}

export interface ApiMonitoringForm {
  id:                        string;
  task_id:                   string;
  sample_point_id:           string;
  observer_name:             string;
  observed_at:               number;
  species:                   string;
  alive_count:               number;
  dead_count:                number;
  dormant_count:             number;
  natural_recovery_count?:   number;
  natural_recovery_species?: string;
  salinity?:                 number;
  crab_burrows?:             number;
  height_cm?:                number;
  stem_diameter_mm?:         number;
  leaf_count?:               number;
  notes?:                    string;
  form_status:               'draft' | 'completed';
  updated_at?:               string;
}

export interface ApiMediaItem {
  id:          string;
  owner_type:  string;
  owner_id:    string;
  type:        'photo' | 'video';
  role:        string;
  remote_url:  string;
  latitude?:   number;
  longitude?:  number;
  taken_at:    number;
  duration_ms?: number;
}

export interface ApiUser {
  id:                  string;
  name:                string;
  email:               string;
  role:                'admin' | 'field_leader';
  assigned_project_id?: string;
}
