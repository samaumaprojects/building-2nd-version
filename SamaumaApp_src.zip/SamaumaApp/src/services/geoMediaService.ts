import Geolocation from '@react-native-community/geolocation';
import { launchCamera, CameraOptions } from 'react-native-image-picker';
import { database, collections } from '../models/database';
import { Q } from '@nozbe/watermelondb';

export interface GeoMediaResult {
  localId:   string;
  localUri:  string;
  latitude:  number;
  longitude: number;
  accuracy:  number;
  takenAt:   number;
  mediaType: 'photo' | 'video';
}

function getCurrentGps(): Promise<{ latitude: number; longitude: number; accuracy: number }> {
  return new Promise((resolve) => {
    Geolocation.getCurrentPosition(
      pos => resolve({
        latitude:  pos.coords.latitude,
        longitude: pos.coords.longitude,
        accuracy:  pos.coords.accuracy ?? 999,
      }),
      () => resolve({ latitude: 0, longitude: 0, accuracy: 999 }),
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 5000 },
    );
  });
}

/**
 * Capture a geo-tagged photo.
 * role: 'fotoponto' | 'borda' | 'session_photo'
 * ownerType: 'monitoring_form' | 'planting_session' | 'project'
 */
export async function captureGeoPhoto(
  ownerId:   string,
  ownerType: string,
  role:      string = 'session_photo',
): Promise<GeoMediaResult | null> {
  return new Promise(resolve => {
    const options: CameraOptions = {
      mediaType:     'photo',
      quality:       0.8,
      saveToPhotos:  false,
      includeBase64: false,
    };

    launchCamera(options, async (response) => {
      if (response.didCancel || response.errorCode || !response.assets?.[0]) {
        resolve(null);
        return;
      }
      const asset = response.assets[0];
      const { latitude: lat, longitude: lng, accuracy } = await getCurrentGps();
      const takenAt = Date.now();
      let localId = '';

      await database.write(async () => {
        const record = await collections.media().create(m => {
          m.ownerType = ownerType;
          m.ownerId   = ownerId;
          m.mediaType = 'photo';
          m.role      = role;
          m.localUri  = asset.uri!;
          m.latitude  = lat;
          m.longitude = lng;
          m.accuracy  = accuracy;
          m.takenAt   = takenAt;
          m.synced    = false;
        });
        localId = record.id;
      });

      resolve({ localId, localUri: asset.uri!, latitude: lat, longitude: lng, accuracy, takenAt, mediaType: 'photo' });
    });
  });
}

/**
 * Capture a geo-tagged video.
 */
export async function captureGeoVideo(
  ownerId:   string,
  ownerType: string,
): Promise<GeoMediaResult | null> {
  return new Promise(resolve => {
    const options: CameraOptions = {
      mediaType:     'video',
      videoQuality:  'high',
      durationLimit: 120,
      saveToPhotos:  false,
    };

    launchCamera(options, async (response) => {
      if (response.didCancel || response.errorCode || !response.assets?.[0]) {
        resolve(null);
        return;
      }
      const asset = response.assets[0];
      const { latitude: lat, longitude: lng, accuracy } = await getCurrentGps();
      const takenAt = Date.now();
      let localId = '';

      await database.write(async () => {
        const record = await collections.media().create(m => {
          m.ownerType  = ownerType;
          m.ownerId    = ownerId;
          m.mediaType  = 'video';
          m.role       = 'session_video';
          m.localUri   = asset.uri!;
          m.latitude   = lat;
          m.longitude  = lng;
          m.accuracy   = accuracy;
          m.takenAt    = takenAt;
          m.durationMs = asset.duration ? Math.round(asset.duration * 1000) : null;
          m.synced     = false;
        });
        localId = record.id;
      });

      resolve({ localId, localUri: asset.uri!, latitude: lat, longitude: lng, accuracy, takenAt, mediaType: 'video' });
    });
  });
}

export async function getMediaForOwner(ownerId: string, ownerType: string) {
  return collections.media().query(
    Q.where('owner_id', ownerId),
    Q.where('owner_type', ownerType),
  ).fetch();
}

export async function deleteMediaItem(localId: string) {
  await database.write(async () => {
    const item = await collections.media().find(localId);
    await item.markAsDeleted();
  });
}
