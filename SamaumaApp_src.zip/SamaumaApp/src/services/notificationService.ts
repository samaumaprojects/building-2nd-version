import messaging from '@react-native-firebase/messaging';
import notifee, { AndroidImportance } from '@notifee/react-native';
import api from './api';

// navigationRef deve ser importado do seu RootNavigator
import { navigationRef } from '../navigation/RootNavigator';

export async function setupNotifications() {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;
  if (!enabled) return;

  const token = await messaging().getToken();
  await api.patch('/users/me', { fcm_token: token }).catch(() => {});

  // Canal Android
  await notifee.createChannel({
    id:         'monitoring',
    name:       'Monitoramento',
    importance: AndroidImportance.HIGH,
  });

  // Mensagem em foreground
  messaging().onMessage(async remote => {
    await notifee.displayNotification({
      title:   remote.notification?.title ?? 'Samaúma',
      body:    remote.notification?.body,
      android: { channelId: 'monitoring', pressAction: { id: 'default' } },
    });
  });

  // App em background — toque na notificação
  messaging().onNotificationOpenedApp(remote => {
    const { screen, taskId } = (remote.data ?? {}) as any;
    if (screen === 'MonitoringTask' && taskId) {
      navigationRef.current?.navigate('Tarefa', { taskId });
    }
  });

  // App fechado — aberto via notificação
  const initial = await messaging().getInitialNotification();
  if ((initial?.data as any)?.taskId) {
    navigationRef.current?.navigate('Tarefa', { taskId: (initial!.data as any).taskId });
  }
}
