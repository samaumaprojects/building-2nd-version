import NetInfo from '@react-native-community/netinfo';
import { Q } from '@nozbe/watermelondb';
import RNFS from 'react-native-fs';
import { database, collections } from '../models/database';
import api, { API_BASE_URL } from './api';
import { useAuthStore } from '../features/auth/authStore';

let _syncInProgress = false;

export function initSyncListener() {
  NetInfo.addEventListener(state => {
    if (state.isConnected && !_syncInProgress) {
      runSync();
    }
  });
}

/**
 * Sync order per spec: monitoring_forms → planting_sessions → media_items
 */
export async function runSync() {
  if (_syncInProgress) return;
  _syncInProgress = true;
  try {
    await syncMonitoringForms();
    await syncPlantingSessions();
    await syncMedia();
  } finally {
    _syncInProgress = false;
  }
}

async function syncMonitoringForms() {
  const pending = await collections.forms()
    .query(Q.where('synced', false)).fetch();

  for (const form of pending) {
    if (!form.remoteId) {
      // New form — POST
      try {
        const { data } = await api.post('/monitoring-forms', {
          task_id:                   form.taskId,
          sample_point_id:           form.samplePointId,
          observer_name:             form.observerName,
          observed_at:               form.observedAt,
          species:                   form.species,
          alive_count:               form.aliveCount,
          dead_count:                form.deadCount,
          dormant_count:             form.dormantCount,
          natural_recovery_count:    form.naturalRecoveryCount,
          natural_recovery_species:  form.naturalRecoverySpecies,
          salinity:                  form.salinity,
          crab_burrows:              form.crabBurrows,
          height_cm:                 form.heightCm,
          stem_diameter_mm:          form.stemDiameterMm,
          leaf_count:                form.leafCount,
          notes:                     form.notes,
          form_status:               form.formStatus,
        });
        await database.write(async () => {
          await form.update(r => {
            r.remoteId = String(data.id);
            r.synced   = true;
          });
        });
      } catch (e) {
        console.warn('MonitoringForm sync failed', form.id, e);
      }
    } else {
      // Existing form — PUT
      try {
        await api.put(`/monitoring-forms/${form.remoteId}`, {
          alive_count:              form.aliveCount,
          dead_count:               form.deadCount,
          dormant_count:            form.dormantCount,
          natural_recovery_count:   form.naturalRecoveryCount,
          natural_recovery_species: form.naturalRecoverySpecies,
          salinity:                 form.salinity,
          crab_burrows:             form.crabBurrows,
          height_cm:                form.heightCm,
          stem_diameter_mm:         form.stemDiameterMm,
          leaf_count:               form.leafCount,
          notes:                    form.notes,
          form_status:              form.formStatus,
        });
        await database.write(async () => {
          await form.update(r => { r.synced = true; });
        });
      } catch (e) {
        console.warn('MonitoringForm update sync failed', form.id, e);
      }
    }
  }
}

async function syncPlantingSessions() {
  const pending = await collections.sessions()
    .query(Q.where('synced', false)).fetch();

  for (const session of pending) {
    try {
      let coords: any[] = [];
      if (session.polygonJson) {
        const polygon = JSON.parse(session.polygonJson);
        if (polygon?.coordinates?.[0]) {
          coords = polygon.coordinates[0].map(([lng, lat]: [number, number]) => ({ latitude: lat, longitude: lng }));
        }
      }

      const { data } = await api.post(`/projects/${session.projectId}/sessions`, {
        name:            session.name,
        type:            session.type,
        sponsor_id:      session.sponsorId,
        methodology:     session.methodology,
        conditions:      session.conditions,
        assessor_id:     session.assessorId,
        started_at:      session.startedAt,
        species_counts:  session.speciesCounts,
        total_seedlings: session.totalSeedlings,
        area_ha:         session.areaHa,
        spacing_m:       session.spacingM,
        plantable_pct:   session.plantablePct,
        polygon:         session.polygon,
        polygon_source:  session.polygonSource,
      });

      await database.write(async () => {
        await session.update(r => {
          r.remoteId = String(data.id);
          r.synced   = true;
        });
      });
    } catch (e) {
      console.warn('PlantingSession sync failed', session.id, e);
    }
  }
}

async function syncMedia() {
  const pending = await collections.media()
    .query(Q.where('synced', false)).fetch();

  for (const item of pending) {
    try {
      const filePath = item.localUri.replace('file://', '');
      const exists = await RNFS.exists(filePath);
      if (!exists) {
        console.warn('Media file not found:', item.localUri);
        continue;
      }

      const isVideo    = item.mediaType === 'video';
      const filename   = item.localUri.split('/').pop() ?? (isVideo ? 'video.mp4' : 'photo.jpg');
      const filetype   = isVideo ? 'video/mp4' : 'image/jpeg';

      const response = await RNFS.uploadFiles({
        toUrl: `${API_BASE_URL}/media`,
        files: [{
          name:     'file',
          filename,
          filepath: filePath,
          filetype,
        }],
        method: 'POST',
        headers: {
          Authorization: `Bearer ${useAuthStore.getState().token}`,
          'Content-Type': 'multipart/form-data',
        },
        fields: {
          owner_type: item.ownerType,
          owner_id:   item.ownerId,
          type:       item.mediaType,
          role:       item.role,
          taken_at:   String(item.takenAt),
          latitude:   item.latitude != null ? String(item.latitude) : '',
          longitude:  item.longitude != null ? String(item.longitude) : '',
          accuracy:   item.accuracy != null ? String(item.accuracy) : '',
        },
      }).promise;

      const serverData = JSON.parse(response.body);
      await database.write(async () => {
        await item.update(m => {
          m.remoteId  = String(serverData.id);
          m.remoteUrl = serverData.remote_url;
          m.synced    = true;
        });
      });
    } catch (e) {
      console.warn('Media sync failed', item.id, e);
    }
  }
}
